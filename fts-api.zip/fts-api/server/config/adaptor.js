/*jshint esversion: 8 */
const path = require('path');
// Get all the settings
const setting = require('./settings.dev');

module.exports = {
	name: 'FTS V2 API Server',
	env: setting.appEnv,
	port: setting.appPort,
	logs: setting.appLog,
	// ip:'localhost', // This will not let app accesible on LAN
	ip: setting.appHost,

	root: path.normalize(`${__dirname}/../..`), // Root
	base: path.normalize(`${__dirname}/..`), // Base

	loginAPIServer: setting.loginAPIServer,

	dsAPIKey: setting.dsAPIKey,

	logFileName: {
		info: 'info.log',
		error: 'exceptions.log',
	},
	db: {
		pg: {
			// PGSQL - Sample URI
			// uri: 'postgres://user:pass@example.com:5432/dbname'
			uri: (() => {
				// If Username Password is set
				if (setting.pgdbIsAuth === 'true') {
					return `postgres://${setting.pgdbUsername}:${setting.pgdbPassword}@${setting.pgdbHost}:${setting.pgdbPort}/${setting.pgDbName}`;
				}
				// Without auth
				return `postgres://${setting.pgdbHost}:${setting.pgdbPort}/${setting.pgDbName}`;
			})(),

			masterDb: `${setting.pgDbName}`,
			options: {},
			host: setting.pgdbHost,
			port: setting.pgdbPort,
			username: setting.pgdbUsername,
			password: setting.pgdbPassword,
		},
	},
	jwtSignature: {
		accessSecret: setting.accessTokenSecret,
		refreshSecret: setting.refreshTokenSecret,
	},
	swaggerBaseUrl: setting.swaggerBaseUrl,
	googleMapToken: setting.googleMapToken,
	minio: setting.minio,
	twilio: setting.twilio,
	payment: setting.payment,
};

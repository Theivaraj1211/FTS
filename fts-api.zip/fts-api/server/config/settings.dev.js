module.exports = {
	reverse_geo_api_key: '665502fb0545419abfdc5e8f168e0370',
	pgdbHost: process.env.FTS_PGDB_HOST || process.env.PGDB_HOST || 'localhost',
	pgdbPort: process.env.FTS_PGDB_PORT || process.env.PGDB_PORT || '9000',
	pgdbIsAuth:
		process.env.FTS_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || 'true',
	pgdbUsername:
		process.env.FTS_PGDB_USERNAME || process.env.PGDB_USERNAME || 'master',
	pgdbPassword:
		process.env.FTS_PGDB_PASSWORD ||
		process.env.PGDB_PASSWORD ||
		'DHNNOQIYWMDZZPOQ',

	pgDbName: process.env.PGDB_NAME || 'fts-app-v2',

	appPort: process.env.FTS_API_PORT || 3031,
	appHost: process.env.FTS_API_HOST || '0.0.0.0',

	appEnv: process.env.FTS_API_ENV || 'dev',
	appLog: process.env.FTS_API_LOG || 'dev',

	accessTokenSecret:
		process.env.FTS_API_ACCESS_TOKEN_SECRET ||
		'F4AE2797BA2DE610139037BE30173DCEEAFBB8ABB37CE60B81FD0BEC738F646A',
	refreshTokenSecret:
		process.env.FTS_API_REFRESH_TOKEN_SECRET ||
		'EFBF25E19309E46E1640E32322F56398D9D9726FD202DE0DCF18F199C6CE923B',
	swaggerBaseUrl:
		process.env.SWAGGER_BASE_URL ||
		'https://ftsv2.api.hyperthings.in/api/v1/swagger',
	googleMapToken:
		process.env.GOOGLE_MAP_TOKEN || 'AIzaSyBkrKVdqYKJP7PI5JbcmGt7x9YoReSkgf0',

	minio: {
		url: process.env.MINIO_URL || 'iot.hyperthings.in',
		accessKey: process.env.MINIO_ACCESSKEY || 'xcHwoEOYiOYDksDz',
		secretKey: process.env.MINIO_SECRETKEY || 'nAZSIkmTHnxDlyeY',
		port: process.env.MINIO_PORT || 17208,
		bucket_name: process.env.MINIO_BUCKET_NAME || 'fts',
		publicUrl: process.env.MINIO_PUBLIC_URL || 'https://cdn.hyperthings.in',
		imageBaseUrl:
			process.env.IMAGE_BASE_URL || 'http://iot.hyperthings.in:17208/fts/',
	},
	from:
		process.env.SP_EMAIL_FROM ||
		process.env.EMAIL_FROM ||
		'notification.fts@gmail.com',
	mailService:
		process.env.SP_SCHEDULER_MAIL_SERVICE ||
		process.env.MAIL_SERVICE ||
		'gmail',
	mailHost:
		process.env.SP_SCHEDULER_MAIL_HOST ||
		process.env.MAIL_HOST ||
		'smtp.gmail.com',
	mailPort: process.env.SP_SCHEDULER_MAIL_PORT || process.env.MAIL_PORT || 465,
	mailSecure:
		process.env.SP_SCHEDULER_MAIL_SECURE || process.env.MAIL_SECURE || true,
	mailUser:
		process.env.SP_SCHEDULER_MAIL_USER ||
		process.env.MAIL_USER ||
		'notification.smartparkingsys@gmail.com',
	mailPassword:
		process.env.SP_SCHEDULER_MAIL_PASSWORD ||
		process.env.MAIL_PASSWORD ||
		'papwjlxomwbfclez',
	mailUnauthorized:
		process.env.SP_SCHEDULER_MAIL_REJECT_UNAUTHORIZED ||
		process.env.MAIL_REJECT_UNAUTHORIZED ||
		false,
};

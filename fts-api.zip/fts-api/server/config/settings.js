module.exports = {
	pgdbHost: process.env.FTS_PGDB_HOST || process.env.PGDB_HOST || 'localhost',
	pgdbPort: process.env.FTS_PGDB_PORT || process.env.PGDB_PORT || '54324',
	pgdbIsAuth: process.env.FTS_PGDB_IS_AUTH || process.env.PGDB_IS_AUTH || 'true',
	pgdbUsername:
		process.env.FTS_PGDB_USERNAME ||
		process.env.PGDB_USERNAME ||
		'master',
	pgdbPassword:
		process.env.FTS_PGDB_PASSWORD ||
		process.env.PGDB_PASSWORD ||
		'DHNNOQIYWMDZZPOQ',

	pgDbName: process.env.PGDB_NAME || 'fts-app-v2',

	appPort: process.env.FTS_API_PORT || 3031,
	appHost: process.env.FTS_API_HOST || '0.0.0.0',

	appEnv: process.env.FTS_API_ENV || 'dev',
	appLog: process.env.FTS_API_LOG || 'dev',

	accessTokenSecret:
		process.env.FTS_API_ACCESS_TOKEN_SECRET ||
		'F4AE2797BA2DE610139037BE30173DCEEAFBB8ABB37CE60B81FD0BEC738F646A',
	refreshTokenSecret:
		process.env.FTS_API_REFRESH_TOKEN_SECRET ||
		'EFBF25E19309E46E1640E32322F56398D9D9726FD202DE0DCF18F199C6CE923B',
	swaggerBaseUrl:
		process.env.SWAGGER_BASE_URL || 'http://localhost:3031/api/v1/swagger',
	googleMapToken:
		process.env.GOOGLE_MAP_TOKEN || 'AIzaSyBkrKVdqYKJP7PI5JbcmGt7x9YoReSkgf0',

};

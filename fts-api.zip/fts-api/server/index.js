// Import Server
const App = require('./server');
// Import Settings
const { port, name, ip } = require('./config/adaptor');

// Instantiate App
const app = new App();
// Start KOA server
app.listen(port, ip, () => {
	console.log(`\n-------\n ${name}listening on ${ip}:${port}, \n-------`);
});

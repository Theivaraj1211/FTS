'use strict';
// Import JWT
const Jwt = require('jsonwebtoken');
// Import Settings
const { jwtSignature } = require('../../../config/adaptor');
// Import Response Util
const Response = require('../utils/response');
// Import Prisma Client
const prismaClient = require("../utils/prisma.client")
class Auth {
	constructor() {}
	// JWT - Authentcation
	static jwtAuth = async (ctx, next) => {
		console.log( "*******Request Body-------******" , ctx.request.body)
		try {
			if (ctx.headers.authorization) {
				const authHeader = ctx.headers.authorization;
				// If No Auth token
				if (!authHeader) {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'No Token Provided',
					});
				}
				// Split token
				const token = authHeader.split(' ')[1]; // Authorization: Bearer token
				if (!token || token === '') {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'No Token Provided',
					});
				}

				const decoded = await Jwt.verify(token, jwtSignature.accessSecret);
				// Pass on the user to next controller
				ctx.state.user = decoded;
				// Next
				await next();
			}
			// IF the user is a guest user
			else if (ctx.headers.android_id) {
				ctx.state.android_id = ctx.headers.android_id;
				await next();
			}
			else {
				// No Authorization header found
				return Response.unauthorized(ctx, {
				  statusCode: 401,
				  code: 41,
				  msg: 'Unable to verify your credentials',
				});
			  }
		} catch (err) {
			console.log(err);
			return Response.unauthorized(ctx, {
				statusCode: 401,
				code: 41,
				msg: 'Unable to verify your credentials',
			});
		}
	};

	// JWT - Authentcation
	static adminAuth = async (ctx, next) => {
		try {
			if (ctx.headers.authorization) {
				const authHeader = ctx.headers.authorization;
				// If No Auth token
				if (!authHeader) {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'No Token Provided',
					});
				}
				// Split token
				const token = authHeader.split(' ')[1]; // Authorization: Bearer token
				if (!token || token === '') {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'No Token Provided',
					});
				}

				const checkToken = await prismaClient.users.findFirst({
					where: {
						token,
					},
				});
				if (!checkToken) {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 43,
						msg: 'Please login again!',
					});
				}

				const decoded = await Jwt.verify(token, jwtSignature.accessSecret);
				// Pass on the user to next controller
				ctx.state.user = decoded;
				// Next
				await next();
			} // IF the user is a guest user
			else if (ctx.headers.kiosk) {
				ctx.state.kiosk = ctx.headers.kiosk;
				await next();
			}
		} catch (err) {
			console.log(err);
			return Response.unauthorized(ctx, {
				statusCode: 401,
				code: 41,
				msg: 'Unable to verify your credentials',
			});
		}
	};
}



// Export
module.exports = Auth;

// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Parse BigInt
const ParseBigInt = require('../utils/parse.bigint');

// To change BigInt into Json
const getCountryCodeId = async (dial_code) => {
	try {
		const x_raw = await prismaClient.country_code.findUnique({
			where: {
				dial_code,
			},
		});
		const x = await ParseBigInt(x_raw);
		return x;
	} catch (e) {
		console.log('error', e);
	}
};

// Export
module.exports = getCountryCodeId;

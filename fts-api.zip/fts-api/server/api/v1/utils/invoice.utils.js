// Import Prisma Client
const prismaClient = require('./prisma.client');
class Invoice {
	constructor() {}

	static crateInvoice = async (reservationId) => {
		try {
			let invoiceId;
			reservationId = Number(reservationId);
			// Get Reservation Details
			const reservationDetails = await prismaClient.reservations.findFirst({
				where: {
					id: reservationId,
				},
				select: {
					id: true,
					amount: true,
					vas_orders: {
						select: {
							amount: true,
							qty: true,
						},
					},
				},
			});

			// IF No Reservaton Found
			if (!reservationDetails) {
				throw 'No Reservation found!';
			}

			// Check is Invoice Exist
			const isInvoiceExist = await prismaClient.invoices.findFirst({
				where: {
					reservation_id: reservationId,
				},
				select: {
					id: true,
				},
			});

			if (!isInvoiceExist) {
				// Create a new invoices
				const createInvoice = await prismaClient.invoices.create({
					data: {
						reservation_id: reservationId,
						invoice_status_id: 1,
					},
					select: {
						id: true,
					},
				});
				invoiceId = createInvoice.id;

				// Update invoice id in reservation table
				await prismaClient.reservations.update({
					data: {
						invoice_id: invoiceId,
					},
					where: {
						id: reservationId,
					},
				});
			} else {
				// Get Invoice Id
				invoiceId = isInvoiceExist.id;
				// Delete all Old items
				await prismaClient.invoice_items.deleteMany({
					where: {
						invoice_id: invoiceId,
					},
				});
			}

			let invoiceItems = [];
			const parkingAmount = {
				invoice_id: invoiceId,
				item_id: 1,
				flow_id: 1,
				amount: reservationDetails.amount,
			};
			invoiceItems.push(parkingAmount);
			// Vas Order Items
			reservationDetails.vas_orders.map((v) => {
				const qty = v.qty || 1;
				const amount = v.amount * qty;
				const items = {
					invoice_id: invoiceId,
					item_id: 2,
					flow_id: 1,
					amount,
				};
				invoiceItems.push(items);
			});

			// Add Invoice Items
			await prismaClient.invoice_items.createMany({
				data: invoiceItems,
			});

			// Get Total Amount
			const totalAmount = await prismaClient.invoice_items.aggregate({
				_sum: {
					amount: true,
				},
				where: {
					invoice_id: invoiceId,
				},
			});
			// Calculate Total Amount
			const tAmount = totalAmount._sum.amount;
			// Calculate Tax Amount
			let taxAmount = parseFloat((tAmount * 0.15).toFixed(2));
			// taxAmount.toFixed(2);
			// Calculate Payable Amount
			const payableAmount = parseFloat(tAmount + taxAmount);
			console.log(taxAmount);
			// Update Invoice
			const updateInvoice = await prismaClient.invoices.update({
				data: {
					total_amount: tAmount,
					tax: taxAmount,
					payable_amount: payableAmount,
				},
				select: {
					payable_amount: true,
					paid_amount: true,
				},
				where: {
					id: invoiceId,
				},
			});

			return updateInvoice;
		} catch (error) {
			console.log(error);
			throw Error('Create Invoice Error', error);
		}
	};
}

// Export
module.exports = Invoice;

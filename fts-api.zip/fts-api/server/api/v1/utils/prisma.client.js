const { PrismaClient  , AlertsScalarFieldEnum  } = require('@prisma/client');
const { db } = require('../../../config/adaptor');

// Importing prisma client
let prisma = new PrismaClient({
	datasources: {
		db: {
			url: db.pg.uri,
		},
	},
	// Specifying the logs when use prisma client
	log: ['query', 'info', 'warn', 'error'],
});

// Anonymous function to state when the connect with the database is made
(async () => {
	try {
		await prisma.$connect();
		console.log('DB is connected');
	} catch (error) {
		console.log('DB is not connected', error);
		return;
	}
})();

// Export
module.exports = prisma;

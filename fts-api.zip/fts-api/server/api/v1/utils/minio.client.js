/* eslint-disable indent */
var Minio = require('minio');
var settings = require('../../../config/settings.dev');
var minioClient = new Minio.Client({
    endPoint: settings.minio.url,
    port: settings.minio.port,
    useSSL: false,
    accessKey: settings.minio.accessKey,
    secretKey: settings.minio.secretKey,
});

// const  policiy = 
// minioClient.makeBucket('fts', 'us-east-1', function (err) {
//     if (err) return console.log(err);
//     console.log('Bucket created successfully in "us-east-1".');
// });
// minioClient.setBucketPolicy(settings.minio.bucket_name, 'read');



module.export = minioClient;




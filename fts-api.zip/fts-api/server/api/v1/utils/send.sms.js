// Import twilio configs
const { twilio } = require('../../../config/adaptor');

const sendSms = (phone, message) => {
	const client = require('twilio')(twilio.accountSid, twilio.authToken);

	client.messages
		.create({
			body: message,
			from: twilio.TWILIO_PHONE_NUMBER,
			to: `+91${phone}`,
		})
		.then((message) => console.log(message.sid))
		.catch((error) => console.log(error));
};

// Export
module.exports = sendSms;

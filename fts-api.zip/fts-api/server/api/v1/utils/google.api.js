// Import Google maps
const { Client } = require('@googlemaps/google-maps-services-js');
const client = new Client({});
// Import settings
const { googleMapToken } = require('./../../../config/adaptor');
// Import axios for hitting the google api
var axios = require('axios');
// Decode polyline and get the array of coordinates
const decodePolyline = require('decode-google-map-polyline');

// Get distance and time between a origin and array of destination
const googleApi = async (lat, lng, arr) => {
	try {
		let array = [];
		const r = await client.distancematrix({
			params: {
				origins: [{ lat: lat, lng: lng }], // 5 Location //Coordinates // Google Matrix API
				destinations: arr,
				mode: 'driving', // DRIVING
				unitSystem: 0,
				avoidHighways: false,
				avoidTolls: false,
				key: googleMapToken,
			},
			timeout: 1000, // Milliseconds
		});
		r.data.rows.map((one) => {
			array.push(one.elements);
		});
		return array[0];
	} catch (e) {
		console.log('error', e);
	}
};

// Get direction between two points
const directions = async (origin, destination) => {
	try {
		const data = {
			polyline: '',
			coordinates: [],
		};
		var config = {
			method: 'get',
			url: `https://maps.googleapis.com/maps/api/directions/json?destination=${destination}&origin=${origin}&key=${googleMapToken}`,
			destination,
			origin,
			headers: {},
		};

		const polylineRaw = await axios(config);

		const polyline = polylineRaw.data.routes[0].overview_polyline.points;

		data.polyline = polyline;
		// Extract coordinates from the google polylines
		data.coordinates = decodePolyline(polyline);

		return data;
	} catch (e) {
		console.log('error', e);
	}
};

// Export
module.exports = { googleApi, directions };

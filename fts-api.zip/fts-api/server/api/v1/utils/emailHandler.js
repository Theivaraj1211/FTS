'use strict';
const nodemailer = require('nodemailer');
const config = require('../../../config/settings.dev');
//const constants = require('../utils/constants');
//const logger = require('../../../config/settings.dev');

async function sendEmail(toEmail, subject, mailBody) {
	let mailOptions = {
		from: config.from,
		to: toEmail,
		subject: subject,
		text: mailBody,
	};
	let TransportObj = {
		host: config.mailHost,
		port: config.mailPort,
		secure: config.mailSecure,
		auth: {
			user: config.mailUser,
			pass: config.mailPassword,
		},
		tls: {
			rejectUnauthorized: config.mailUnauthorized,
		},
	};

	let transporter = nodemailer.createTransport(TransportObj);

	try {
		await transporter.sendMail(mailOptions);
		`Email sent to ${toEmail}`;
		`File : ${fileName}`;
		return true;
	} catch (error) {
		`Error while sending email : ${error}`;
		return false;
	}
}

module.exports = {
	sendDailyMail: async (toEmail, subject, mailBody) => {
		try {
			sendEmail(toEmail, subject, mailBody);
			return true;
		} catch (error) {
			return false;
		}
	},
};

//
module.exports = sendEmail;

// const sendEmail = async function main() {
// 	// create reusable transporter object using the default SMTP transport
// 	let transporter = nodemailer.createTransport({
// 		host: config.mailHost,
// 		port: config.mailPort,
// 		secure: config.mailSecure, // true for 465, false for other ports
// 		auth: {
// 			user: config.mailUser, // generated ethereal user
// 			pass: config.mailPassword, // generated ethereal password
// 		},
// 	});
// 	// send mail with defined transport object
// 	let info = await transporter.sendMail({
// 		from: config.from, // sender address
// 		to: 'avinashkrjha7@gmail.com', // list of receivers
// 		subject: 'OTP', // Subject line
// 		text: 'Notification', // plain text body
// 		html: '<b>Your OTP Is </b>', // html body
// 	});

// 	console.log('Message sent: %s', info.messageId);
// 	// Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
// };

// sendEmail().catch(console.error);
//-----------------------

'use strict';
// Import https
const https = require('https');
// Utils
class Utils {
	constructor() {}
	static convertBigIntToInt(key, obj = []) {
		obj.forEach((value, index, array) => {
			value[key] = Number(value[key]);
			array[index] = value;
		});
		return obj;
	}

	static downloadQrCode = (url) => {
		return new Promise((resolve, reject) => {
			https
				.request(url, function (response) {
					response.on('data', function (chunk) {
						resolve(chunk);
					});
					// response.on('end', function () {
					// 	fs.writeFileSync('server/api/v1/qr/' + fileName, data.read());

					// });
					response.on('error', function (err) {
						console.log(err);
						reject(err);
					});
				})
				.end();
		});
	};

	static paymentStatus = (code) => {
		// Payment Success
		const successPattern = /^(000\.000\.|000\.100\.1|000\.[36])/;
		if (successPattern.test(code)) {
			return 'success';
		}
		// Payment Pending
		const pendingPattern = /^(000\.200)/;
		if (pendingPattern.test(code)) {
			return 'pending';
		}
		// Payment Reject
		return 'reject';
	};

	static getHours = (start_time, end_time) => {
		const timeDiff =
			new Date(end_time).getTime() - new Date(start_time).getTime();
		// get hours
		let hh =
			Math.ceil(timeDiff / 1000 / 60 / 60) > 0
				? Math.ceil(timeDiff / 1000 / 60 / 60)
				: 1;
		return hh;
	};
}

// Export
module.exports = Utils;

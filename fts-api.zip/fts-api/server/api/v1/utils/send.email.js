const nodemailer = require('nodemailer');
const fs = require('fs');
const ejs = require('ejs');
const setting = require('../../../config/adaptor');

const smtp = nodemailer.createTransport({
	host: setting.smtp.host,
	port: setting.smtp.port,
	secure: setting.smtp.secure,
	auth: {
		user: setting.smtp.user,
		pass: setting.smtp.pass,
	},
	tls: {
		rejectUnauthorized: false,
	},
});

(async () => {
	smtp.verify((err) => {
		if (!err) {
			console.log('Server is ready to take our messages');
		}
	});
})();

const sendEmail = async ({
	template: templateName,
	data: templateVrs,
	...restOfOptions
}) => {
	const constOptions = { from: 'dilip@hyperthings.in' };
	const options = { ...restOfOptions, ...constOptions };
	const templatePath = `server/api/v1/templates/${templateName}.html`;
	if (fs.existsSync(templatePath)) {
		const template = fs.readFileSync(templatePath, 'utf-8');
		const html = ejs.render(template, templateVrs);
		options.html = html;
		return new Promise((resolve, reject) => {
			smtp.sendMail(options, (err, info) => {
				if (!err) {
					console.log(info);
					resolve(true);
				}
				reject(err);
			});
		});
	}
	console.log('Template Not Found');
};

// Export
module.exports = { sendEmail };

/* eslint-disable indent */
const axios = new require('axios');
const { reverse_geo_api_key } = new require('../../../config/settings.dev');

// var config = {
//     'latitude': 40.00403611111111,
//     'longitude': 116.48485555555555
// };

// geocoding(config, function (err, data){
//     if(err){
//         console.log(err);
//     }else{
//         console.log(data);
//     }
// });

const getAddress = async(lat, lng) => {
    console.log(reverse_geo_api_key);
    // console.log(lat,lng);
    const url = `https://api.opencagedata.com/geocode/v1/json?q=${lat}+${lng}&key=${reverse_geo_api_key}`;
    // console.log(url);
    try{
        const output = await axios({method : 'get' , url : url});
        console.log(output.data.results[0].formatted);
        return output.data.results[0].formatted;
    }catch(err){
        console.log(err);
        return null;
    }
    // await axios.get(url)
    //     .then(function (res) {
    //         return res.data.results[0].formatted;
    //     })
    //     .catch(function (err) {
    //         console.log(err);
    //         return null;
    //     });
};


module.exports = getAddress;
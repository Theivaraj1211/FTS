// To change BigInt into Json
const parseBigInt = async (data) => {
	try {
		const x = JSON.parse(
			JSON.stringify(
				data,
				(key, value) => (typeof value === 'bigint' ? value.toString() : value) // return everything else unchanged
			)
		);
		return x;
	} catch (e) {
		console.log('error', e);
	}
};

// Export
module.exports = parseBigInt;

'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/geofence');


// router.get('/search/',Controller.SearchGeofences);
router.get('/:id', Controller.getGeofenceById);
router.post('/', Controller.creategeofence);
router.put('/:id', Controller.updateById);
router.get('/', Controller.getAllgeofence);
router.delete('/:id', Controller.deleteGeofence);


module.exports = router;
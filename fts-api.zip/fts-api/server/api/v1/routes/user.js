'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('./../controllers/user');
// Import Auth - Middleware
const Auth = require('./../middlewares/auth');
/*
 
! New User Routes


*/

//Search User
router.get('/search/', Controller.SearchUser);
// Signin user
router.post('/signin', Controller.signin);

// Get All Roles
router.get('/roles', Auth.jwtAuth, Controller.getAllRoles);

// Get All User
router.get('/', Auth.jwtAuth, Controller.getAllUsers);

// create-user
router.post('/', Auth.jwtAuth, Controller.signup);

// Update Users
router.patch('/', Auth.jwtAuth, Controller.updateUser);

//Delete User By Id
router.delete('/', Auth.jwtAuth, Controller.deleteUser);

// Generate otp to confirm user email
router.post('/generate-otp', Controller.generateOtp);

// Confirm otp for a user
router.post('/confirm-otp', Controller.confirmOtp);

// Reset Password
router.patch('/update-password', Auth.jwtAuth, Controller.updatePassword);

// forgot Password
router.patch('/forgot-password', Controller.forgotPassword);

// Get profile
router.get('/profile', Controller.getProfile);

// Update profile Password
router.patch('/profilePassword', Controller.updateProfilePassword);

//
//Admin Routes
// Signin
//router.post('/admin-signin', Controller.adminSignin);
//router.post('/admin-signin', Controller.adminSignin);

// Signin api
router.post('/web-signin', Controller.signinWeb);

// User Signup
router.post('/web-signup', Controller.signupWeb);

// Generate otp to confirm user email/number
router.post('/web-generate-otp', Controller.generateOtpWeb);

// Confirm otp for a user
router.post('/web-confirm-otp', Controller.confirmOtpWeb);

// Forgot password
router.post('/web-forgot-password', Controller.forgotPasswordWeb);

// Guest Signup
router.post('/add-guest-user', Controller.addGuestUser);

// Get titles
router.get('/titles', Controller.titles);

// Test API
//router.get('/', Controller.getAllUsers);

// Forgot password
router.post('/forgot-password', Controller.forgotPassword);

// Get profile
router.get('/profile', Auth.jwtAuth, Controller.getProfile);

// Update profile
router.patch('/profile', Auth.jwtAuth, Controller.updateProfile);

// Get OTP
router.post('/get-otp', Controller.getOtp);

// Get OTP
router.get('/get-country-code', Controller.getCountryCode);

// Send Email

// router.get('/send', Controller.send);

// Export
module.exports = router;

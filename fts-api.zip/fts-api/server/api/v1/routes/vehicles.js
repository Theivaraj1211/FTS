'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/vehicles');

// create vehicle
router.post('/', Controller.createvehicle);
//udate vehicle 
router.get('/', Controller.getAllVehicle);
router.get('/unassigned',Controller.getAllUnassignedVehicle);
// Route to get a vehicle by ID
router.get('/:id', Controller.getVehicleById);
router.delete('/:id', Controller.deleteVehicle);
// Route to update a vehicle by ID
router.put('/:id', Controller.updateVehicleById);
// router.post('/geofenceAssignment', Controller.createGeoFenceAssignment);
// router.post('/routeAssignment', Controller.createRouteAssignment);

module.exports = router;

'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/route_assignments');



router.post('/', Controller.createrouterassignment);

router.get('/', Controller.getAllRoutesAssignment);

router.get('/:id', Controller.getRoutesAssignmentById);

router.put('/:id', Controller.updateRoutesAssignmentById);

router.delete('/:id', Controller.deleteRouteAssignment);
// Export
module.exports = router;

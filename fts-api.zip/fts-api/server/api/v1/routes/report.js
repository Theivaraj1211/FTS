'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('./../controllers/report');
// Import Auth - Middleware
const Auth = require('./../middlewares/auth');

/*
 
! New Alert Routes

*/
//Get All Report Types
router.get('/types', Controller.getAllReportTypes);
// Get All Report
router.get('/', Controller.getAllReports);
// Get Status Report
router.get('/status', Controller.getStatusReports);




















// Export
module.exports = router;
/* eslint-disable indent */
'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/command');
// Import Auth - Middleware
// const Auth = require('../middlewares/auth');

// Get list of fleet
router.get('/', Controller.getAllCommands);
// to get the count for all fleet
router.post('/', Controller.createCommand);


module.exports = router;
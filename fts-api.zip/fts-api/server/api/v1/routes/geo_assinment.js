'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/geofence_assignment');

router.post('/', Controller.creategeofenceassignment);
router.get('/',Controller.getAllgeofenceAssignment);
router.get('/:id',Controller.getGeofenceAssignmentById);
router.put('/:id',Controller.updateAssignmentById);
module.exports = router;
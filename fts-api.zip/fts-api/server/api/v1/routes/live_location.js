
'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/live_location');


router.get('/live_location/:vehicle_id', Controller.getLiveLocation);

// Export
module.exports = router;

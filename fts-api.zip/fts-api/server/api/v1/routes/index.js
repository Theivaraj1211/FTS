'use strict';
// Import Koa Router
const Router = require('koa-router');
// Import User Routes
const User = require('./user');

// Import Report Routes
const Reports = require('./report')

const Drivers = require('./drivers');

// Import Alert Routes
const ALerts = require('./alert');
// Import dashbord Routes
const Dashboard = require('./dashboard');
//Import Vehicle Routes
const Vehicles = require('./vehicles');
//Import Vehicles routes
const Geofence = require('./geofences');
const GeofenceAssignment = require('./geo_assinment');
const RouterAssignment = require('./router_assignment');
const Manufacture = require('./manfacture');
const Routes = require('./routes');
const ImageUpload = require('./image_upload');
const liveLocation = require('./live_location');
const VechicleType = require('./vehicleType');
const Devices = require('./devices');
const Commands = require('./command');
const OtherInfo = require('./otherInfo');
// Import Swagger json file
const swaggerConfig = require('../../../swagger.json');

// Instantiate Router
const router = new Router({
	prefix: '/api/v1',
});

// Test Route
router.get('/status', (ctx) => {
	ctx.body = 'Running!';
});

// Swagger Route
router.get('/swagger', (ctx) => {
	ctx.body = swaggerConfig;
});

// User Routes
router.use('/users', User.routes());
// Report Routes
router.use('/reports', Reports.routes());
// Alert Routes
router.use('/alerts', ALerts.routes());
// Dashboard route
router.use('/home', Dashboard.routes());
//drivers route
router.use('/drivers', Drivers.routes());

//vehical Routes
router.use('/vehicles', Vehicles.routes());

//geofence routes
router.use('/geofence', Geofence.routes());

//geofence assignment routes
router.use('/geofenceAssignment', GeofenceAssignment.routes());

//router assignment routes
router.use('/routerAssignment', RouterAssignment.routes());

// rouetes route
router.use('/routes', Routes.routes());

//imageupload route
router.use('/vechiclemaufacture', Manufacture.routes());
router.use('/vehicletype', VechicleType.routes());
router.use('/imgUpload', ImageUpload.routes());

//devices routes
router.use('/devices', Devices.routes());

//fleet routes
router.use('/fleet', liveLocation.routes());


//commands routes
router.use('/commands',Commands.routes());

//other info routes
router.use('/other_info',OtherInfo.routes());

//

// Export
module.exports = router;

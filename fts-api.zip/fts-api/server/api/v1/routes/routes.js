'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/routes');

router.get('/search/',Controller.SearchRoutes);
router.post('/', Controller.createroutes);
router.put('/:id', Controller.updateById);
router.get('/:id', Controller.getRoutesById);
router.get('/', Controller.getAllRoutes);
router.delete('/:id', Controller.deleteRoute);

// Export
module.exports = router;

/* eslint-disable indent */
'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/otherInfo');
// Import Auth - Middleware
// const Auth = require('../middlewares/auth');
//create driver
router.get('/:vehicle_id', Controller.getOtherInfo);

module.exports = router;

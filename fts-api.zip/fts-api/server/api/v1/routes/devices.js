'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/devices');

router.get('/', Controller.getDevices);
router.get('/unassigned', Controller.getUnasiggnedDevices);


module.exports = router;

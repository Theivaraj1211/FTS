'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('./../controllers/alert');
// Import Auth - Middleware
const Auth = require('./../middlewares/auth');

/*
 
! New Alert Routes

*/

// Get All Alert
router.get('/', Controller.getAllAlerts);

// Get  Alert By Id
router.get('/id', Controller.getAlertsById);

// Get All Alerts Types BY Id
router.get('/byId', Controller.getAllAlertTypesById);

// Get Alerts by Vehicle Id
router.get('/getAlertsById', Controller.getAlertsByVehicleId);

// Get All Fleets
router.get('/fleets', Controller.getAllFleets);

// Get All Alerts-Graph
router.get('/alerts-count', Controller.getAllAlertsCount);


















// Export
module.exports = router;
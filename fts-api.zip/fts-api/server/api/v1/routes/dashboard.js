/* eslint-disable indent */
'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/dashboard');
// Import Auth - Middleware
// const Auth = require('../middlewares/auth');

// Get list of fleet
router.get('/fleet-list', Controller.fleetList);
// to get the count for all fleet
router.get('/count', Controller.count);

// to get the count for all fleet
router.get('/getCount', Controller.countById);

module.exports = router;

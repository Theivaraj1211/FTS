/* eslint-disable indent */
'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/drivers');
// Import Auth - Middleware
// const Auth = require('../middlewares/auth');
//create driver
router.post('/', Controller.createDriver);
//update driver
router.put('/', Controller.updateDriver);
//delete driver
router.delete('/', Controller.deleteDriver);
//get driver
router.get('/', Controller.getDrivers);
router.get('/getDriverById', Controller.getDriversByID);
// router.get('/titles', Controller.titles);

// router.get('/profile', Auth.jwtAuth, Controller.getProfile);
module.exports = router;

'use strict';
// Import Koa Router
const Router = require('koa-router');
// Instantiate Router
const router = new Router();
// Import Controller
const Controller = require('../controllers/vehicletype');

router.get('/', Controller.getAllVehicleType);

module.exports = router;
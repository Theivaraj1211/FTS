/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class vehicalcontroller {
    constructor() { }
    static async deleteVehicle(ctx) {
        try {
            const deletedVehicle = await prismaClient.vehicles.delete({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'vehicles Deleted',
                data: deletedVehicle
            });
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error deleting vehicle',
                error: err
            });
        }
    }
    // static async createGeoFenceAssignment(ctx) {
    //     if (!ctx.request.query.geofenceID && !ctx.request.query.vehicleID) {
    //         return Response.badRequest(ctx, {
    //             code: 500,
    //             msg: 'please provide geofenceID and vehicleID',
    //         });
    //     }
    //     try {
    //         const check = await prismaClient.geofence_assignment.findFirst({
    //             where: {
    //                 geofence_id: parseInt(ctx.request.query.geofenceID),
    //                 vehicle_id: parseInt(ctx.request.query.vehicleID),
    //             }
    //         });
    //         if (check) {
    //             return Response.error(ctx, {
    //                 code: 50,
    //                 msg: 'assignment with same details already present',
    //                 data: check
    //             });
    //         }
    //         const output = await prismaClient.geofence_assignment.create({
    //             data: {
    //                 geofence_id: parseInt(ctx.request.query.geofenceID),
    //                 vehicle_id: parseInt(ctx.request.query.vehicleID),
    //             }
    //             , select: {
    //                 id: true,
    //                 created_at: true,
    //                 vehicles: true,
    //                 geofences: true
    //             }
    //         })
    //             .catch((e) => {
    //                 console.log(e);
    //                 return Response.internalServerError(ctx, {
    //                     code: 500,
    //                     msg: 'unable to assign geofence',
    //                     error: e
    //                 });
    //             });
    //         return Response.created(ctx, {
    //             code: 200,
    //             msg: 'Vehicle geofence assignment created successfully',
    //             data: output,
    //         });
    //     } catch (error) {
    //         console.log(error);
    //         return Response.internalServerError(ctx, {
    //             code: 500,
    //             msg: 'Internal Server Error'
    //         });
    //     }
    // }
    // static async createRouteAssignment(ctx) {
    //     if (!ctx.request.query.routeID && !ctx.request.query.vehicleID) {
    //         return Response.badRequest(ctx, {
    //             code: 500,
    //             msg: 'please provide routeID and vehicleID',
    //         });
    //     }
    //     try {
    //         const check = await prismaClient.route_assignments.findFirst({
    //             where: {
    //                 route_id: parseInt(ctx.request.query.routeID),
    //                 vehicle_id: parseInt(ctx.request.query.vehicleID),
    //             }
    //         });
    //         if (check) {
    //             return Response.error(ctx, {
    //                 code: 50,
    //                 msg: 'assignment with same details already present',
    //                 data: check
    //             });
    //         }
    //         const output = await prismaClient.route_assignments.create({
    //             data: {
    //                 route_id: parseInt(ctx.request.query.routeID),
    //                 vehicle_id: parseInt(ctx.request.query.vehicleID),
    //             }
    //             , select: {
    //                 id: true,
    //                 created_at: true,
    //                 vehicles: true,
    //                 routes: true
    //             }
    //         }).catch((e) => {
    //             console.log(e);
    //             return Response.internalServerError(ctx, {
    //                 code: 500,
    //                 msg: 'unable to assign route',
    //                 error: e
    //             });
    //         });
    //         return Response.created(ctx, {
    //             code: 200,
    //             msg: 'Vehicle route assignment created successfully',
    //             data: output,
    //         });
    //     } catch (error) {
    //         console.log(error);
    //         return Response.internalServerError(ctx, {
    //             code: 500,
    //             msg: 'Internal Server Error'
    //         });
    //     }
    // }
    static async createvehicle(ctx) {
        try {
            console.log('--------create vehicle----------');
            // Get Input
            const schema = Joi.object({
                name: Joi.string(),
                vehicle_no: Joi.string(),
                vehicle_type_id: Joi.number().integer(),
                mfr_id: Joi.number(),
                owner: Joi.string(),
                engine_no: Joi.string(),
                chassis_no: Joi.string(),
                make: Joi.string(),
                year_of_mfg: Joi.string(),
                unladen_weight: Joi.string(),
                service_date: Joi.date(),
                next_service: Joi.date(),
                insurance_no: Joi.string(),
                insurance_period: Joi.string(),
                insurance_date: Joi.date(),
                road_tax_no: Joi.string(),
                road_tax_period: Joi.string(),
                road_tax_renew_date: Joi.date(),
                sim_card_serial_no: Joi.string(),
                mobile_no: Joi.string(),
                existing_plan: Joi.string(),
                plan_validity: Joi.date(),
                rfid_no: Joi.string(),
                device_id: Joi.number()
            });
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }
            // Check if vehicleNo already exists in the database
            // const existingVehicle = await prismaClient.vehicles.findFirst({
            //     where: {
            //         vehicle_no: inputs.value.vehicle_no,
            //     }
            // });
            // console.log(existingVehicle);
            // if (existingVehicle) {
            //     return Response.conflict(ctx, {
            //         code: 409,
            //         msg: 'Vehicle already exists in the database',
            //     });
            // }

            const vehicleReturn = await prismaClient.vehicles.findFirst({
                where: {
                    OR: [
                        { chassis_no: inputs.value.chassis_no },
                        { engine_no: inputs.value.engine_no },
                        { vehicle_no: inputs.value.vehicle_no },
                        { insurance_no: inputs.value.insurance_no },
                        { rfid_no: inputs.value.rfid_no },
                        { mobile_no: inputs.value.mobile_no },
                        { sim_card_serial_no: inputs.value.sim_card_serial_no },
                    ],
                },
            });
            // const checkDriver = await ParseBigInt(vehicleReturn);
                // If exists return
                console.log(vehicleReturn);
                if (vehicleReturn) {
                    if (vehicleReturn.sim_card_serial_no == inputs.value.sim_card_serial_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'vehicle already registered with same sim_card_serial_no !',
                            msg: 'vehicle already registered with same sim_card_serial_no!',
                        });
                    }
                    if (vehicleReturn.chassis_no == inputs.value.chassis_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'vehicle already registered with same chassis number !',
                            msg: 'vehicle already registered with same chassis number !',
                        });
                    }
                    if (vehicleReturn.engine_no == inputs.value.engine_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'vehicle already registered with same engine number !',
                            msg: 'vehicle already registered with same engine number !',
                        });
                    }
                    if (vehicleReturn.insurance_no == inputs.value.insurance_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'vehicle already registered with same insurance no !',
                            msg: 'vehicle already registered with same insurance no !',
                        });
                    }
                    if (vehicleReturn.mobile_no == inputs.value.mobile_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error:
                                'vehicle already registered with same mobile_no !',
                            msg: 'vehicle already registered with same mobile_no !',
                        });
                    }
                    if (vehicleReturn.vehicle_no == inputs.value.vehicle_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error:
                                'vehicle already registered with same mobile_no !',
                            msg: 'vehicle already registered with same mobile_no !',
                        });
                    }
                    if (vehicleReturn.rfid_no == inputs.value.rfid_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error:
                                'vehicle already registered with same mobile_no !',
                            msg: 'vehicle already registered with same mobile_no !',
                        });
                    }
                }

            // Create new vehicle
            const newVehicle = await prismaClient.vehicles.create({
                data: inputs.value
            });
            // Return success response
            return Response.created(ctx, {
                code: 200,
                msg: 'Vehicle created successfully',
                data: newVehicle,
            });

        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }



    //update 
    static async updateVehicleById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const existingVehicle = await prismaClient.vehicles.findFirst({
                where: { id }
            });
            if (!existingVehicle) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'Vehicle not found'
                });
            }
            const schema = Joi.object({
                name: Joi.string(),
                vehicle_no: Joi.string(),
                vehicle_type_id: Joi.number().integer(),
                mfr_id: Joi.number(),
                owner: Joi.string(),
                engine_no: Joi.string(),
                chassis_no: Joi.string(),
                year_of_mfg: Joi.string(),
                unladen_weight: Joi.string(),
                service_date: Joi.date(),
                next_service: Joi.date(),
                insurance_no: Joi.string(),
                insurance_period: Joi.string(),
                insurance_date: Joi.date(),
                road_tax_no: Joi.string(),
                road_tax_period: Joi.string(),
                road_tax_renew_date: Joi.date(),
                sim_card_serial_no: Joi.string(),
                mobile_no: Joi.string(),
                existing_plan: Joi.string(),
                plan_validity: Joi.date(),
                rfid_no: Joi.string(),
                device_id: Joi.number(),
                is_active: Joi.boolean(),
            });

            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 400,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details
                });
            }

            // const vehicleReturn = await prismaClient.vehicles.findFirst({
            //     where: {
            //         OR: [
            //             { chassis_no: inputs.value.chassis_no },
            //             { engine_no: inputs.value.engine_no },
            //             { vehicle_no: inputs.value.vehicle_no },
            //             { insurance_no: inputs.value.insurance_no },
            //             { rfid_no: inputs.value.rfid_no },
            //             { mobile_no: inputs.value.mobile_no },
            //             { sim_card_serial_no: inputs.value.sim_card_serial_no },
            //         ],
            //     },
            // });
            // // const checkDriver = await ParseBigInt(vehicleReturn);
            //     // If exists return
            //     console.log(vehicleReturn);
            //     if (vehicleReturn) {
            //         if (vehicleReturn.sim_card_serial_no == inputs.value.sim_card_serial_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error: 'vehicle already registered with same sim_card_serial_no !',
            //                 msg: 'vehicle already registered with same sim_card_serial_no!',
            //             });
            //         }
            //         if (vehicleReturn.chassis_no == inputs.value.chassis_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error: 'vehicle already registered with same chassis number !',
            //                 msg: 'vehicle already registered with same chassis number !',
            //             });
            //         }
            //         if (vehicleReturn.engine_no == inputs.value.engine_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error: 'vehicle already registered with same engine number !',
            //                 msg: 'vehicle already registered with same engine number !',
            //             });
            //         }
            //         if (vehicleReturn.insurance_no == inputs.value.insurance_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error: 'vehicle already registered with same insurance no !',
            //                 msg: 'vehicle already registered with same insurance no !',
            //             });
            //         }
            //         if (vehicleReturn.mobile_no == inputs.value.mobile_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error:
            //                     'vehicle already registered with same mobile_no !',
            //                 msg: 'vehicle already registered with same mobile_no !',
            //             });
            //         }
            //         if (vehicleReturn.vehicle_no == inputs.value.vehicle_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error:
            //                     'vehicle already registered with same mobile_no !',
            //                 msg: 'vehicle already registered with same mobile_no !',
            //             });
            //         }
            //         if (vehicleReturn.rfid_no == inputs.value.rfid_no) {
            //             return Response.success(ctx, {
            //                 code: 41,
            //                 error:
            //                     'vehicle already registered with same mobile_no !',
            //                 msg: 'vehicle already registered with same mobile_no !',
            //             });
            //         }
            //     }
                console.log(inputs.value, id);
                if (inputs.value.device_id != existingVehicle && inputs.value.device_id != null || undefined) {
                    await prismaClient.devices.update({
                        where: {
                            id: existingVehicle.device_id
                        },
                        data: {
                            vehicle_id: null
                        }
                    });
                }
                var body = inputs.value;
                // delete body.device_id ;
                // console.log(body,'------------');
                if (inputs.value.device_id == existingVehicle.device_id && inputs.value.device_id != null || undefined) {
                    delete body.device_id;
                }
                const updatedVehicle = await prismaClient.vehicles.update({
                    where: { id: id },
                    data: body,
                    // include:{
                    //     vehicle_manufacturers : true ,  
                    //     vehicle_types : true,
                    //     devices :true 
                    // },
                    select: {
                        vehicle_manufacturers: true,
                        vehicle_types: true,
                        devices: true
                    }
                });
                if (inputs.value.device_id != existingVehicle && inputs.value.device_id != null || undefined) {
                    await prismaClient.vehicle_assignments.update({
                        where: {
                            vehicle_id: updatedVehicle.id
                        },
                        data: {
                            device_id: updatedVehicle.device_id
                        }
                    });
                }
                return Response.ok(ctx, {
                    code: 200,
                    msg: 'Vehicle updated successfully',
                    data: updatedVehicle
                });
            } catch (error) {
                console.log(error);
                return Response.internalServerError(ctx, {
                    code: 500,
                    msg: 'Internal Server Error'
                });
            }
        }

    static async getVehicleById(ctx) {
        try {
            console.log('********************get vehicles by id ***************************');
            const id = parseInt(ctx.params.id);
            const vehicle = await prismaClient.vehicles.findFirst({
                where: { id },
                select: {
                    chassis_no: true,
                    created_at: true,
                    id: true,
                    engine_no: true,
                    insurance_date: true,
                    existing_plan: true,
                    geofence_assignment: {
                        select: {
                            id: true,
                            is_active: true,
                            geofences: {
                                select: {
                                    name: true,
                                    id: true,
                                    is_active: true,
                                    updated_at: true
                                }
                            }
                        }
                    },
                    route_assignments: {
                        select: {
                            routes: true,
                            id: true,
                        }
                    },
                    insurance_no: true,
                    insurance_period: true,
                    mobile_no: true,
                    year_of_mfg: true,
                    plan_validity: true,
                    vehicle_no: true,
                    rfid_no: true,
                    device_id: true,
                    devices: true,
                    vehicle_types: {
                        select: {
                            id: true,
                            name: true
                        }
                    },
                    vehicle_manufacturers: {
                        select: {
                            id: true,
                            name: true
                        }
                    },

                },
                // include:{
                //     devices : true,
                // }
            });
            // const deviceDetails = await prismaClient.devices.findFirst({
            //     where: {
            //         id: vehicle.device_id
            //     }
            // });

            // const driverDetails = await prismaClient.drivers.findFirst({
            //     where: {
            //         vehicle_id: vehicle.id
            //     }
            // });

            const driverDetails = await prismaClient.vehicle_assignments.findFirst({
                where: {
                    vehicle_id: vehicle.id
                },
                include: {
                    drivers: true
                }
            });
            vehicle.driver = driverDetails.drivers;
            // vehicle.device = deviceDetails;
            console.log(vehicle);
            // const vehicleLastLocation = await prismaClient.device_data.findFirst({

            //     where: {
            //         uid: vehicle.device.uid
            //     },
            //     select: {
            //         lat: true,
            //         lng: true
            //     }
            // });
            // const vehicleFirstLocation = await prismaClient.device_data.findFirst({
            //     orderBy: {
            //         time: 'asc'
            //     },
            //     where: {
            //         uid: vehicle.device.uid
            //     },
            //     select: {
            //         lat: true,
            //         lng: true
            //     }
            // });
            vehicle.last_location = {
                lng: vehicle.devices.lng,
                lat: vehicle.devices.lat
            };
            // vehicle.first_location = vehicleFirstLocation;
            // console.log(vehicle,);
            if (!vehicle) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'Vehicle not found'
                });
            }
            return Response.ok(ctx, {
                code: 200,
                msg: 'Success',
                data: vehicle
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }

    static async getAllVehicle(ctx) {
        try {
            const limit = +ctx.request.query.limit || 10;
            const offset = +ctx.request.query.offset || 0;
            const search = ctx.request.query.search;
            var vehicle;
            // var ids = await prismaClient.vehicle_assignments.findMany({
            //     select : {
            //         vehicle_id: true
            //     }
            // });
            // var id = [];
            // ids.map((iteam,index)=>{    
            //     id[index] = iteam.vehicle_id;
            // });
            if (search != 0 && search != undefined) {

                vehicle = await prismaClient.vehicles.findMany({
                    orderBy: {
                        updated_at: 'desc'
                    },
                    where: {
                        OR: [
                            {
                                vehicle_no: {
                                    contains: search,
                                    mode: 'insensitive'
                                }
                            }, {
                                name: {
                                    contains: search,
                                    mode: 'insensitive'
                                }
                            }
                        ],
                    },
                    skip: offset,
                    take: limit,
                    select: {
                        chassis_no: true,
                        created_at: true,
                        updated_at: true,
                        device_id: true,
                        devices: true,
                        id: true,
                        is_active: true,
                        engine_no: true,
                        insurance_date: true,
                        existing_plan: true,
                        geofence_assignment: {
                            select: {
                                id: true,
                                is_active: true,
                                geofences: {
                                    select: {
                                        name: true,
                                        id: true,
                                        is_active: true,
                                        updated_at: true
                                    }
                                }
                            }
                        },
                        route_assignments: {
                            include: {
                                routes: true
                            }
                        },
                        insurance_no: true,
                        name: true,
                        unladen_weight: true,
                        next_service: true,
                        owner: true,
                        road_tax_no: true,
                        road_tax_period: true,
                        road_tax_renew_date: true,
                        service_date: true,
                        vehicle_assignments: true,
                        sim_card_serial_no: true,
                        insurance_period: true,
                        mobile_no: true,
                        year_of_mfg: true,
                        plan_validity: true,
                        vehicle_no: true,
                        rfid_no: true,
                        vehicle_types: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                        vehicle_manufacturers: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                    },
                });
                // console.log(vehicle);
                // for(var i ; i  < vehicle.length ; i ++){
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: vehicle[i].device_id
                //         }
                //     });
                //     vehicle[i].device = deviceDetails;
                // }
                // vehicle.map(async (iteam, index) => {
                //     // console.log(iteam, index);
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: iteam.device_id
                //         }
                //     });
                //     vehicle[index].device = deviceDetails;
                // });
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Vehicles successful',
                    data: vehicle,
                    count: vehicle.length
                });
            } else {
                vehicle = await prismaClient.vehicles.findMany({
                    orderBy: {
                        updated_at: 'desc'
                    },
                    skip: offset,
                    take: limit,
                    select: {
                        chassis_no: true,
                        created_at: true,
                        updated_at: true,
                        id: true,
                        is_active: true,
                        engine_no: true,
                        insurance_date: true,
                        existing_plan: true,
                        device_id: true,
                        devices: true,
                        geofence_assignment: {
                            select: {
                                id: true,
                                is_active: true,
                                geofences: {
                                    select: {
                                        name: true,
                                        id: true,
                                        is_active: true,
                                        updated_at: true
                                    }
                                }
                            }
                        },
                        route_assignments: {
                            include: { routes: true, vehicle_status: true }
                        },
                        insurance_no: true,
                        name: true,
                        unladen_weight: true,
                        next_service: true,
                        owner: true,
                        road_tax_no: true,
                        road_tax_period: true,
                        road_tax_renew_date: true,
                        service_date: true,
                        vehicle_assignments: true,
                        sim_card_serial_no: true,
                        insurance_period: true,
                        mobile_no: true,
                        year_of_mfg: true,
                        plan_validity: true,
                        vehicle_no: true,
                        rfid_no: true,
                        vehicle_types: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                        vehicle_manufacturers: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                    },
                });
                // console.log(vehicle);
                // for(var j ; j  < vehicle.length ; j ++){
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: vehicle[j].device_id
                //         }
                //     });
                //     vehicle[j].device = deviceDetails;
                // }

                // vehicle.map(async (iteam, index) => {
                //     // console.log(iteam, index);
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: iteam.device_id
                //         }
                //     });
                //     vehicle[index].device = deviceDetails;
                // });
                const totalCount = await prismaClient.vehicles.count();
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Vehicles successful',
                    data: vehicle,
                    count: totalCount
                });
            }


        } catch (err) {
            console.log(err);
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting vehicles',
                error: err
            });
        }
    }




    static async getAllUnassignedVehicle(ctx) {
        try {
            const limit = +ctx.request.query.limit || 10;
            const offset = +ctx.request.query.offset || 0;
            const search = ctx.request.query.search;
            var vehicle;
            var ids = await prismaClient.vehicle_assignments.findMany({
                select: {
                    vehicle_id: true
                }
            });
            var id = [];
            ids.map((iteam, index) => {
                id[index] = iteam.vehicle_id;
            });
            if (search != 0 && search != undefined) {

                vehicle = await prismaClient.vehicles.findMany({
                    orderBy: {
                        updated_at: 'desc'
                    },
                    where: {
                        OR: [
                            {
                                vehicle_no: {
                                    contains: search,
                                    mode: 'insensitive'
                                }
                            }, {
                                name: {
                                    contains: search,
                                    mode: 'insensitive'
                                }
                            }
                        ],
                        id: {
                            notIn: id
                        }
                    },
                    skip: offset,
                    take: limit,
                    select: {
                        chassis_no: true,
                        created_at: true,
                        updated_at: true,
                        device_id: true,
                        devices: true,
                        id: true,
                        is_active: true,
                        engine_no: true,
                        insurance_date: true,
                        existing_plan: true,
                        geofence_assignment: {
                            select: {
                                id: true,
                                is_active: true,
                                geofences: {
                                    select: {
                                        name: true,
                                        id: true,
                                        is_active: true,
                                        updated_at: true
                                    }
                                }
                            }
                        },
                        insurance_no: true,
                        name: true,
                        unladen_weight: true,
                        next_service: true,
                        owner: true,
                        road_tax_no: true,
                        road_tax_period: true,
                        road_tax_renew_date: true,
                        service_date: true,
                        vehicle_assignments: true,
                        sim_card_serial_no: true,
                        insurance_period: true,
                        mobile_no: true,
                        year_of_mfg: true,
                        plan_validity: true,
                        vehicle_no: true,
                        rfid_no: true,
                        vehicle_types: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                        vehicle_manufacturers: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                    },
                });
                // console.log(vehicle);
                // for(var i ; i  < vehicle.length ; i ++){
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: vehicle[i].device_id
                //         }
                //     });
                //     vehicle[i].device = deviceDetails;
                // }
                // vehicle.map(async (iteam, index) => {
                //     // console.log(iteam, index);
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: iteam.device_id
                //         }
                //     });
                //     vehicle[index].device = deviceDetails;
                // });
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Vehicles successful',
                    data: vehicle,
                    count: vehicle.length
                });
            } else {
                vehicle = await prismaClient.vehicles.findMany({
                    orderBy: {
                        updated_at: 'desc'
                    },
                    where: {

                        id: {
                            notIn: id
                        }
                    },
                    skip: offset,
                    take: limit,
                    select: {
                        chassis_no: true,
                        created_at: true,
                        updated_at: true,
                        id: true,
                        is_active: true,
                        engine_no: true,
                        insurance_date: true,
                        existing_plan: true,
                        device_id: true,
                        devices: true,
                        geofence_assignment: {
                            select: {
                                id: true,
                                is_active: true,
                                geofences: {
                                    select: {
                                        name: true,
                                        id: true,
                                        is_active: true,
                                        updated_at: true
                                    }
                                }
                            }
                        },
                        insurance_no: true,
                        name: true,
                        unladen_weight: true,
                        next_service: true,
                        owner: true,
                        road_tax_no: true,
                        road_tax_period: true,
                        road_tax_renew_date: true,
                        service_date: true,
                        vehicle_assignments: true,
                        sim_card_serial_no: true,
                        insurance_period: true,
                        mobile_no: true,
                        year_of_mfg: true,
                        plan_validity: true,
                        vehicle_no: true,
                        rfid_no: true,
                        vehicle_types: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                        vehicle_manufacturers: {
                            select: {
                                id: true,
                                name: true
                            }
                        },
                    },
                });
                // console.log(vehicle);
                // for(var j ; j  < vehicle.length ; j ++){
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: vehicle[j].device_id
                //         }
                //     });
                //     vehicle[j].device = deviceDetails;
                // }

                // vehicle.map(async (iteam, index) => {
                //     // console.log(iteam, index);
                //     const deviceDetails = await prismaClient.devices.findFirst({
                //         where: {
                //             id: iteam.device_id
                //         }
                //     });
                //     vehicle[index].device = deviceDetails;
                // });
                // const totalCount = await prismaClient.vehicles.count();
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Vehicles successful',
                    data: vehicle,
                    count: vehicle.length
                });
            }


        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting vehicles',
                error: err
            });
        }
    }
};
'use strict';

// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
const { AlertsScalarFieldEnum } = require('@prisma/client');
// Import Settings
const { jwtSignature } = require('../../../config/adaptor');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');
// Parse BigInt
const ParseBigInt = require('../utils/parse.bigint');
// Get Country code Id of a country
const GetCountryCode = require('../utils/getcountry.code');
// Twilio package for sending message
const sendSms = require('../utils/send.sms');
//Moment Js for Time
const moment = require('moment');
const { alerts } = require('../utils/prisma.client');

// Alert Controller
module.exports = class AlertController {
	constructor() {}

	// All ALerts
	static getAllAlerts = async (ctx) => {
		try {
			const limit = ctx.request.query.limit || 10;
			const offset = ctx.request.query.offset || 0;
			const data = ctx.request.query || new Date().now();
			const search = ctx.request.query.search;
			//var output;
			////////////////////////
			const startDate = new Date(data.date);
			const endDate = new Date(startDate.getTime());

			endDate.setHours(startDate.getHours() + 18);
			endDate.setMinutes(startDate.getMinutes() + 29);
			endDate.setSeconds(startDate.getSeconds() + 59);

			//////////////////////////////////////////////////////////
			if (search != 0 && search != undefined) {
				const output = await prismaClient.alerts.findMany({
					orderBy: {
						id: 'desc',
					},
					where: {
						OR: [
							{
								vehicles: {
									vehicle_no: {
										contains: search,
										mode: 'insensitive',
									},
								},
							},
							{
								alert_types: {
									name: {
										contains: search,
										mode: 'insensitive',
									},
								},
							},
						],
					},
					skip: parseInt(offset),
					take: parseInt(limit),
					select: {
						created_at: true,
						id: true,
						drivers: {
							select: {
								driver_name: true,
								license_no: true,
								driver_phone_no: true,
							},
						},
						alert_types: {
							select: {
								id: true,
								name: true,
								description: true,
							},
						},
						vehicles: {
							select: {
								id: true,
								vehicle_no: true,
								name: true,
							},
						},
						geo_lat: true,
						geo_lng: true,
						geo_name: true,
						geo_id: true,
						severity: true,
						resolved: true,
						resolved_by: true,
						resolved_time: true,
					},
				});
				const searchCount = await prismaClient.alerts.count({
					where: {
						OR: [
							{
								vehicles: {
									vehicle_no: {
										contains: search,
										mode: 'insensitive',
									},
								},
							},
							{
								alert_types: {
									name: {
										contains: search,
										mode: 'insensitive',
									},
								},
							},
						],
					},
				});
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Users successful',
					count: searchCount,
					data: output,
					code: 20,
				});
			} else if (!data.date) {
				const allAlertsList = await prismaClient.alerts.findMany({
					orderBy: [
						{
							id: 'desc',
						},
					],
					skip: parseInt(offset),
					take: parseInt(limit),
					select: {
						created_at: true,
						id: true,
						drivers: {
							select: {
								driver_name: true,
								license_no: true,
								driver_phone_no: true,
							},
						},
						alert_types: {
							select: {
								id: true,
								name: true,
								description: true,
							},
						},
						vehicles: {
							select: {
								id: true,
								vehicle_no: true,
								name: true,
							},
						},
						geo_lat: true,
						geo_lng: true,
						geo_name: true,
						geo_id: true,
						severity: true,
						resolved: true,
						resolved_by: true,
						resolved_time: true,
					},
				});
				const counts = await prismaClient.alerts.count({});
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Alerts successful',
					count: counts,
					data: allAlertsList,
					code: 20,
				});
			} else {
				const alertsList = await prismaClient.alerts.findMany({
					skip: parseInt(offset),
					take: parseInt(limit),
					where: {
						created_at: {
							//equals: localDate.toDate()
							gte: new Date(startDate).toISOString(),
							lte: new Date(endDate).toISOString(),
						},
					},
					orderBy: [
						{
							id: 'desc',
						},
					],
					select: {
						created_at: true,
						id: true,
						drivers: {
							select: {
								driver_name: true,
								id: true,
								driver_phone_no: true,
							},
						},
						alert_types: {
							select: {
								id: true,
								name: true,
								description: true,
							},
						},
						vehicles: {
							select: {
								id: true,
								vehicle_no: true,
							},
						},
						geo_lat: true,
						geo_lng: true,
						geo_name: true,
						geo_id: true,
						severity: true,
						resolved: true,
						resolved_by: true,
						resolved_time: true,
					},
				});
				//235
				const counts = await prismaClient.alerts.count({
					where: {
						created_at: {
							//equals: localDate.toDate()
							gte: new Date(startDate).toISOString(),
							lte: new Date(endDate).toISOString(),
						},
					},
				});
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Alerts successful',
					count: counts,
					data: alertsList,
					code: 20,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting alerts',
				error: err,
			});
		}
	};

	// All ALerts  by  id
	static async getAlertsById(ctx) {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}
		try {
			const output = await prismaClient.alerts.findUnique({
				where: {
					id: parseInt(ctx.request.query.id),
				},
				select: {
					created_at: true,
					id: true,
					drivers: {
						select: {
							driver_name: true,
							id: true,
							driver_phone_no: true,
							license_no: true,
						},
					},
					alert_types: {
						select: {
							id: true,
							name: true,
							description: true,
						},
					},
					vehicles: {
						select: {
							id: true,
							vehicle_no: true,
							engine_no: true,
							name: true,
						},
					},
					geo_lat: true,
					geo_lng: true,
					geo_name: true,
					geo_id: true,
					severity: true,
					resolved: true,
					resolved_by: true,
					resolved_time: true,
				},
			});
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get Alerts successful',
				data: output,
				code: 20,
			});
		} catch (err) {
			console.log(err);
		}
	}

	// All ALerts Types by  id
	static async getAllAlertTypesById(ctx) {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}
		try {
			const output = await prismaClient.alert_types.findUnique({
				where: {
					id: parseInt(ctx.request.query.id),
				},
			});
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get Alerts successful',
				data: output,
				code: 20,
			});
		} catch (err) {
			console.log(err);
		}
	}

	// All ALerts by vehicle id
	static getAlertsByVehicleId = async (ctx) => {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select',
			});
		}
		try {
			const allAlertsList = await prismaClient.alerts.findMany({
				orderBy: [
					{
						id: 'desc',
					},
				],
				where: {
					vehicle_id: parseInt(ctx.request.query.id),
				},
				select: {
					id: true,
					created_at: true,
					vehicles: {
						select: {
							id: true,
							name: true,
							vehicle_no: true,
						},
					},
					resolved: true,
					severity: true,
					alert_types: {
						select: {
							id: true,
							name: true,
							description: true,
						},
					},
					drivers: {
						select: {
							id: true,
							driver_name: true,
							driver_phone_no: true,
						},
					},
					resolved_by: true,
					resolved_time: true,
				},
			});

			if (allAlertsList.length == 0) {
				return Response.notFound(ctx, {
					statusCode: 404,
					msg: 'Not Any ALerts FOr This Vehicles',
				});
			}

			const counts = await allAlertsList.length;
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get Alerts successful',
				data: allAlertsList,
				count: counts,
				code: 20,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting alerts',
				error: err,
			});
		}
	};

	// Get All Fleets
	static getAllFleets = async (ctx) => {
		try {
			const limit = ctx.request.query.limit || 10;
			const offset = ctx.request.query.offset || 0;
			const allFleet = await prismaClient.vehicle_assignments.findMany({
				skip: parseInt(offset),
				take: parseInt(limit),
				select: {
					id: true,
					drivers: {
						select: {
							id: true,
							license_validity: true,
						},
					},
					vehicles: {
						select: {
							id: true,
							vehicle_no: true,
							name: true,
							next_service: true,
							road_tax_renew_date: true,
							insurance_date: true,
							insurance_period: true,
						},
					},
				},
			});

			// data
			const data = await ParseBigInt(allFleet);
			// Create an empty array to store the results
			var results = [];

			// Loop through each fleet object in the data array
			data.forEach(function (fleet) {
				// Get the next service, road tax renew, license validity and insurance dates for the current fleet object
				var current = moment().startOf('day');
				var nextServiceDate = new Date(fleet.vehicles.next_service);
				var roadTaxRenewDate = new Date(fleet.vehicles.road_tax_renew_date);
				var licenseValidityDate = new Date(fleet.drivers.license_validity);
				var insuranceDate = new Date(fleet.vehicles.insurance_date);
				var insurancePeriod = fleet.vehicles.insurance_period;
				const insuranceValidityDate = moment(insuranceDate).add(
					insurancePeriod,
					'months'
				);

				// Calculate the difference in months between the current date and the dates
				// Calculate Insurance Date
				var insuranceDate = moment(insuranceValidityDate, 'YYYY-MM-DD');
				var monthsDifferenceNextInsurance = moment(
					new Date(insuranceDate)
				).diff(new Date(current), 'months');

				if (monthsDifferenceNextInsurance <= 0) {
					monthsDifferenceNextInsurance = 'Expired';
				} else {
					monthsDifferenceNextInsurance = `in ${monthsDifferenceNextInsurance} months `;
				}
				// Calculate Service Date
				var serviceDate = moment(nextServiceDate, 'YYYY-MM-DD');
				var monthsDifferenceNextService = moment(new Date(serviceDate)).diff(
					new Date(current),
					'months'
				);

				if (monthsDifferenceNextService <= 0) {
					monthsDifferenceNextService = 'Expired';
				} else {
					monthsDifferenceNextService = `in ${monthsDifferenceNextService} months `;
				}
				// Calculate Road Tax
				var roadTaxDate = moment(roadTaxRenewDate, 'YYYY-MM-DD');
				var monthsDifferenceNextRoadTax = moment(new Date(roadTaxDate)).diff(
					new Date(current),
					'months'
				);

				if (monthsDifferenceNextRoadTax <= 0) {
					monthsDifferenceNextRoadTax = 'Expired';
				} else {
					monthsDifferenceNextRoadTax = `in ${monthsDifferenceNextRoadTax} months `;
				}
				// Calculate License Validity
				var licenseDate = moment(licenseValidityDate, 'YYYY-MM-DD');
				var monthsDifferenceNextLicenseValidity = moment(
					new Date(licenseDate)
				).diff(new Date(current), 'months');

				if (monthsDifferenceNextLicenseValidity <= 0) {
					monthsDifferenceNextLicenseValidity = 'Expired';
				} else {
					monthsDifferenceNextLicenseValidity = `in ${monthsDifferenceNextLicenseValidity} months `;
				}

				// var monthsDifferenceLicenseValidity =
				// 	(licenseValidityDate.getFullYear() - currentDate.getFullYear()) * 12;
				// monthsDifferenceLicenseValidity -= currentDate.getMonth() + 1;
				// monthsDifferenceLicenseValidity += licenseValidityDate.getMonth() + 1;

				// if (monthsDifferenceLicenseValidity <= 0) {
				// 	monthsDifferenceLicenseValidity = 'Expired';
				// }

				// Create an object with the results for the current fleet object
				var fleetResults = {
					id: fleet.id,
					vehicleId: fleet.vehicles.id,
					driverId: fleet.drivers.id,
					vehicleNo: fleet.vehicles.vehicle_no,
					vehicleName: fleet.vehicles.name,
					license: monthsDifferenceNextLicenseValidity,
					insurance: monthsDifferenceNextInsurance,
					roadTax: monthsDifferenceNextRoadTax,
					nextService: monthsDifferenceNextService,
					rc: 'N/A',
					pollution: 'N/A',
				};

				// Add the object to the results array
				results.push(fleetResults);
			});

			// Output the results array
			//console.log(results);

			//Return//////////////////////////////////
			return Response.success(ctx, {
				code: 20,
				msg: 'get Fleet successful',
				data: results,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting alerts',
				error: err,
			});
		}
	};

	// // All ALerts  Count Graph
	// static getAllAlertsCount = async (ctx) => {
	// 	try {
	// 		const limit = ctx.request.query.limit || 10;
	// 		const offset = ctx.request.query.offset || 0;
	// 		const startTime = ctx.request.query;
	// 		const endTime = ctx.request.query;
	// 		//geofence List
	// 		let geofenceAlertsList = await prismaClient.alerts.findMany({
	// 			skip: parseInt(offset),
	// 			take: parseInt(limit),
	// 			where: {
	// 				created_at: {
	// 					gt: new Date(startTime.startTime).toISOString(),
	// 					lt: new Date(endTime.endTime).toISOString(),
	// 				},
	// 				AND: {
	// 					alert_type_id: 1,
	// 				},
	// 			},
	// 			select: {
	// 				created_at: true,
	// 				id: true,
	// 				alert_types: {
	// 					select: {
	// 						id: true,
	// 						name: true,
	// 					},
	// 				},
	// 			},
	// 		});

	// 		//Temper List
	// 		let temperAlertsList = await prismaClient.alerts.findMany({
	// 			skip: parseInt(offset),
	// 			take: parseInt(limit),
	// 			where: {
	// 				created_at: {
	// 					gt: new Date(startTime.startTime).toISOString(),
	// 					lt: new Date(endTime.endTime).toISOString(),
	// 				},
	// 				AND: {
	// 					alert_type_id: 3,
	// 				},
	// 			},
	// 			select: {
	// 				created_at: true,
	// 				id: true,
	// 				alert_types: {
	// 					select: {
	// 						id: true,
	// 						name: true,
	// 					},
	// 				},
	// 			},
	// 		});

	// 		//Other List
	// 		let otherAlertsList = await prismaClient.alerts.findMany({
	// 			skip: parseInt(offset),
	// 			take: parseInt(limit),
	// 			where: {
	// 				created_at: {
	// 					gt: new Date(startTime.startTime).toISOString(),
	// 					lt: new Date(endTime.endTime).toISOString(),
	// 				},
	// 				AND: {
	// 					alert_type_id: 2,
	// 				},
	// 			},
	// 			select: {
	// 				created_at: true,
	// 				id: true,
	// 				alert_types: {
	// 					select: {
	// 						id: true,
	// 						name: true,
	// 					},
	// 				},
	// 			},
	// 		});

	// 		// function/////
	// 		function reducer(accumulator, currentValue, index) {
	// 			const date = currentValue.created_at.split('T')[0];
	// 			if (!accumulator[date]) {
	// 				accumulator[date] = [];
	// 			}
	// 			accumulator[date].push(currentValue);
	// 			return accumulator;
	// 		}

	// 		//reducer(array)
	// 		//geofenceAlertsList
	// 		geofenceAlertsList = JSON.parse(JSON.stringify(geofenceAlertsList))
	// 		const newArray = geofenceAlertsList.reduce(reducer, {});
	// 		const newGroups = Object.keys(newArray).map((date) => {
	// 			return {
	// 				date,
	// 				data: newArray[date],
	// 				count: newArray[date].length,
	// 			};
	// 		});

	// 		// temperAlertsList
	// 		temperAlertsList = JSON.parse(JSON.stringify(temperAlertsList))
	// 		const newArrays = temperAlertsList.reduce(reducer, {});
	// 		const newGroups1 = Object.keys(newArrays).map((date) => {
	// 			return {
	// 				date,
	// 				data: newArrays[date],
	// 				count: newArrays[date].length,
	// 			};
	// 		});
	// 		//
	// 		// // otherAlertsList
	// 		otherAlertsList = JSON.parse(JSON.stringify(otherAlertsList))
	// 		const newArrays1 = otherAlertsList.reduce(reducer, {});
	// 		const newGroups2 = Object.keys(newArrays1).map((date) => {
	// 			return {
	// 				date,
	// 				data: newArrays1[date],
	// 				count: newArrays1[date].length,
	// 			};
	// 		});

	// 		let result = {
	// 			geofenceList: {
	// 				outOfGeofence: newGroups
	// 			},
	// 			temperList: {
	// 				temper: newGroups1,
	// 			},
	// 			otherList : {
	// 				other : newGroups2,
	// 			},
	// 		};
	// 		//

	// 		return Response.success(ctx, {
	// 			statusCode: 200,
	// 			msg: 'get Alerts successful',
	// 			data: result,
	// 			code: 20,
	// 		});
	// 	} catch (err) {
	// 		console.log(err);
	// 		return Response.error(ctx, {
	// 			statusCode: 500,
	// 			code: 50,
	// 			msg: 'Error getting alerts',
	// 			error: err,
	// 		});
	// 	}
	// };

	// All ALerts  Count Graph
	static getAllAlertsCount = async (ctx) => {
		try {
			const { startTime, endTime, interval } = ctx.request.query;

			//geofence List
			let geofenceAlertsList =
				await prismaClient.$queryRaw`SELECT time_bucket_gapfill(${interval}::interval, a.created_at) as ts , cast(coalesce (count(a.alert_type_id),0) as integer) as total_alert, a.alert_type_id, at2."name" as alert_name  from alerts a join alert_types at2  on (at2.id = a.alert_type_id) WHERE a.created_at  >= ${new Date(
					startTime
				)} AND a.created_at  <= ${new Date(
					endTime
				)} AND a.alert_type_id in(1, 2, 3) group by ts,
			a.alert_type_id, at2."name" order by ts, a.alert_type_id ;`;

			let data = JSON.parse(
				JSON.stringify(geofenceAlertsList, (key, value) => {
					if (typeof value === 'bigint') {
						return value.toString();
					}
					return value;
				})
			);

			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get Alerts successful',
				data: data,
				code: 20,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting alerts',
				error: err,
			});
		}
	};

	// static getAllAlertsCount = async (ctx) => {
	// 	try {
	// 		const limit = ctx.request.query.limit || 10;
	// 		const offset = ctx.request.query.offset || 0;
	// 		const startTime = ctx.request.query
	// 		const endTime = ctx.request.query
	// 			//geofence List
	// 			const geofenceAlertsList = await prismaClient.alerts.groupBy({
	// 				by: [  AlertsScalarFieldEnum.created_at],
	// 				skip: parseInt(offset),
	// 				take: parseInt(limit),
	// 				where: {
	// 					created_at: {
	// 						gt : new Date(startTime.startTime).toISOString(),
	// 						lt: new Date(endTime.endTime).toISOString(),
	// 					},
	// 					AND : {
	// 						alert_type_id : 1
	// 					}
	// 				},
	// 				select: {
	// 					created_at: true,
	// 					id: true,
	// 					alert_type_id : true
	// 					// alert_types: {
	// 					// 	select: {
	// 					// 		id: true,
	// 					// 		name: true,
	// 					// 	},
	// 					// },
	// 				},
	// 			});

	// 			//Temper List
	// 			const temperAlertsList = await prismaClient.alerts.groupBy({
	// 				by: [  AlertsScalarFieldEnum.created_at],
	// 				skip: parseInt(offset),
	// 				take: parseInt(limit),
	// 				where: {
	// 					created_at: {
	// 						gt : new Date(startTime.startTime).toISOString(),
	// 						lt: new Date(endTime.endTime).toISOString(),
	// 					},
	// 					AND : {
	// 						alert_type_id : 2
	// 					}
	// 				},
	// 				select: {
	// 					created_at: true,
	// 					id: true,
	// 					alert_type_id : true
	// 					// alert_types: {
	// 					// 	select: {
	// 					// 		id: true,
	// 					// 		name: true,
	// 					// 	},
	// 					// },
	// 				},
	// 			});

	// 			//group the geofence alerts by date and alert ID
	// 			const geofenceAlertsCount = groupAlertsByDateAndAlertId(geofenceAlertsList);

	// 			//group the temperature alerts by date and alert ID
	// 			const temperAlertsCount = groupAlertsByDateAndAlertId(temperAlertsList);

	// 			function groupAlertsByDateAndAlertId(alerts) {
	// 				const result = {};
	// 				alerts.forEach((alert) => {
	// 				  const date = alert.created_at.toDateString();
	// 				  const alertId = alert.alert_type_id;
	// 				  if (!result[date]) {
	// 					result[date] = {};
	// 				  }
	// 				  if (!result[date][alertId]) {
	// 					result[date][alertId] = 0;
	// 				  }
	// 				  result[date][alertId] += alert._count.id;
	// 				});
	// 				return result;
	// 			  }

	// 			//results
	// 			let result = {
	// 				geofenceList : {
	// 					outOfGeofence: geofenceAlertsList,
	// 					count : (geofenceAlertsList.length)
	// 				},
	// 				temperList : {
	// 					temper: temperAlertsList,
	// 					count : (temperAlertsList.length)
	// 				}
	// 			}

	// 			return Response.success(ctx, {
	// 				statusCode: 200,
	// 				msg: 'get Alerts successful',
	// 				data: result,
	// 				code: 20,
	// 			});

	// 	} catch (err) {
	// 		console.log(err);
	// 		return Response.error(ctx, {
	// 			statusCode: 500,
	// 			code: 50,
	// 			msg: 'Error getting alerts',
	// 			error: err,
	// 		});
	// 	}
	// };
};

/* eslint-disable indent */
'use strict';
// Import Bcrypt

const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class Commandcontroller {
    constructor() { }
    static async getAllCommands(ctx) {
        try {
            const limit = +ctx.request.query.limit || 5;
            const offset = +ctx.request.query.offset || 0;
            const List = await prismaClient.commands.findMany({
                skip: offset,
                take: limit,
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'successful',
                data: List,
                count: List.length
            });
        } catch (err) {
            console.log(err);
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting commands',
                error: err
            });
        }
    }


    static async createCommand(ctx) {
        try {
            const schema = Joi.object({
                device_id: Joi.number().integer(),
                command_by: Joi.number().integer(),
                device_type_id: Joi.number().integer(),
                desc : Joi.string(),
                command_status : Joi.number().integer(),
                data : Joi.array(),
                time : Joi.date()
            });
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 400,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details
                });
            }
            const updated = await prismaClient.commands.create({
                data: inputs.value ,
            });
            return Response.ok(ctx, {
                code: 200,
                msg: 'create command successfully',
                data: updated
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error',
                error : error
            });
        }
    }

};
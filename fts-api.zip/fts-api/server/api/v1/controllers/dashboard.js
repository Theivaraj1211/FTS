/* eslint-disable indent */
'use strict';
//prisma client
const prismaClient = require('../utils/prisma.client');
// Import Settings
// Import JOI
const Joi = require('joi');
const reverseGeo = require('../utils/getLocationFromLatLng');
// Import Response Util
const Response = require('../utils/response');

// Dashboard Controller
module.exports = class DashboardController {
	constructor() {}
	//get All Fleet
	static async fleetList(ctx) {
		try {
			// Input validation
			// const schema = Joi.object({
			// 	limit: Joi.number(),
			// 	offset: Joi.number(),
			// 	search : Joi.string()
			// });

			// const validation = schema.validate(ctx.request.query);

			// if (validation.error) {
			// 	console.log(validation.error);
			// 	return Response.badRequest(ctx, {
			// 		code: 40,
			// 		msg: 'Please provide valid data!',
			// 		error: validation.error.details,
			// 	});
			// }

			const limit = +ctx.request.query.limit || 10;
			const offset = +ctx.request.query.offset || 0;
			const search = ctx.request.query.search;
			var vehicle;
			console.log(search);
			if (search != 0 && search != undefined) {
				console.log('----------123-------');
				await prismaClient.vehicle_assignments.findMany({
					orderBy:{
						updated_at : 'desc'
					},
					where: {
						vehicles: {
							OR: [
								{
									vehicle_no: {
										contains: search,
										mode: 'insensitive'
									}
								},
								{
									name: {
										contains: search,
										mode: 'insensitive'
									}
								}
								
							],
							AND : [
								{
									devices : {
										is_active: true
									}
								}
							]
						}
					},
					// select: {
					// 	id: true,
					// 	device_id: true,
					// 	drivers: {
					// 		select: {
					// 			id: true,
					// 			driver_name: true
					// 		}
					// 	},
						
					// },
					include:{drivers:true,devices:true,vehicles:true},
					skip: offset,
					take: limit,
				}).then(async (d) => {
					vehicle = d;
					for (var i = 0; i < vehicle.length; i++) {
						// console.log(vehicle[i]);
						vehicle[i].geoPoint = {
							geoJson: {
								type: 'Point',
								coordinates: [vehicle[i].devices.lng, vehicle[i].devices.lat]
							}
						};
						// console.log(i);
						vehicle[i].address = await reverseGeo(vehicle[i].devices.lat, vehicle[i].devices.lng);
						// console.log(vehicle[i].address, '-----------');
					}
				});
			} else {
				console.log('sadaafasfasfasfa------------------------------');
				await prismaClient.vehicle_assignments
					.findMany({
						select: {
							id: true,
							device_id: true,
							drivers: {
								select: {
									id: true,
									driver_name: true,
								},
							},
							vehicle_id: true,
							devices: true,
							vehicles: {
								include: {
									vehicle_types: true,
								},
							},
						},
						skip: offset,
						take: limit,
					})
					.then(async (d) => {
						vehicle = d;
						for (var i = 0; i < vehicle.length; i++) {
							console.log(vehicle[i]);
							vehicle[i].geoPoint = {
								geoJson: {
									type: 'Point',
									coordinates: [vehicle[i].devices.lng, vehicle[i].devices.lat],
								},
							};
							// console.log(i);
							vehicle[i].address = await reverseGeo(
								vehicle[i].devices.lat,
								vehicle[i].devices.lng
							);
							// console.log(vehicle[i].address,'-----------');
						}
					});
			}
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get fleets successful',
				data: vehicle,
				code: 20,
				count: vehicle.length,
			});
		} catch (err) {
			console.log(err);
		}
	}

	//get Count Fleet
	static async count(ctx) {
		try {
			let total_fleet = await prismaClient.vehicle_assignments.count();
			let offline =
				await prismaClient.$queryRaw`select count(d.is_online) as offline from vehicle_assignments va join devices d on(d.id=va.device_id) where d.is_active = true
			and d.is_online =false`;
			offline = JSON.parse(
				JSON.stringify(offline, (key, value) => {
					if (typeof value === 'bigint') {
						return value.toString();
					}
					return value;
				})
			);
			let offlineData = parseInt(offline[0].offline);

			let online = +total_fleet - +offlineData;
			let moving =
				await prismaClient.$queryRaw` select count(d.is_moving) as moving from vehicle_assignments va join devices d on(d.id=va.device_id) where d.is_active = true
			and d.is_moving = true `;
			moving = JSON.parse(
				JSON.stringify(moving, (key, value) => {
					if (typeof value === 'bigint') {
						return value.toString();
					}
					return value;
				})
			);
			let movingData = parseInt(moving[0].moving);
			let idle =
				await prismaClient.$queryRaw`select count(d.is_moving) as idle from vehicle_assignments va join devices d on(d.id=va.device_id) where d.is_active = true
			and d.is_moving =false`;
			idle = JSON.parse(
				JSON.stringify(idle, (key, value) => {
					if (typeof value === 'bigint') {
						return value.toString();
					}
					return value;
				})
			);
			let idleData = parseInt(idle[0].idle);
			let total_alert = await prismaClient.alerts.count();
			let geofenceAlert = await prismaClient.alerts.count({
				where: {
					alert_type_id: 1,
				},
			});
			let temperAlert = await prismaClient.alerts.count({
				where: {
					alert_type_id: 3,
				},
			});
			let otherAlert = +total_alert - (+geofenceAlert + +temperAlert);
			let result = {
				total_fleet: total_fleet || 0,
				offline: offlineData || 0,
				online: online || 0,
				moving: movingData || 0,
				idle: idleData || 0,
				totelAlerts: total_alert || 0,
				outOfGeofence: geofenceAlert || 0,
				temper: temperAlert || 0,
				other: otherAlert || 0,
			};

			// );

			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get results successful',
				data: result,
				code: 20,
			});
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting drivers',
				error: err,
			});
		}
	}
	//
	//get Count Fleet By Id
	static async countById(ctx) {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}
		try {
			let total_alert = await prismaClient.alerts.count({
				where: {
					vehicle_id: parseInt(ctx.request.query.id),
				},
			});
			let geofenceAlert = await prismaClient.alerts.count({
				where: {
					vehicle_id: parseInt(ctx.request.query.id),
					alert_type_id: 1,
				},
			});
			let temperAlert = await prismaClient.alerts.count({
				where: {
					vehicle_id: parseInt(ctx.request.query.id),
					alert_type_id: 3,
				},
			});
			let otherAlert = +total_alert - (+geofenceAlert + +temperAlert);
			let result = {
				totelAlerts: total_alert || 0,
				outOfGeofence: geofenceAlert || 0,
				temper: temperAlert || 0,
				other: otherAlert || 0,
			};
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get results successful',
				data: result,
				code: 20,
			});
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting drivers',
				error: err,
			});
		}
	}
};

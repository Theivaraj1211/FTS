/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class geofenceAssignmentcontroller {
	constructor() {}
	static async creategeofenceassignment(ctx) {
		try {
			// Get Input
			const schema = Joi.object({
				vehicle_id: Joi.number(),
				geofence_id: Joi.number(),
				is_active: Joi.boolean().default(true),
			});
			const inputs = schema.validate(ctx.request.body);
			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			//--------------------
			// Find the geofence_assignment based on geofence_id and vehicle_id
			const existingGeofenceAssignment =
				await prismaClient.geofence_assignment.findFirst({
					where: {
						// geofence_id: parseInt(inputs.value.geofence_id),
						vehicle_id: parseInt(inputs.value.vehicle_id),
                        is_active :true
					},
				});

			if (existingGeofenceAssignment) {
				// Update the existing geofence_assignment
				await prismaClient.geofence_assignment.update({
					where: {
						id: existingGeofenceAssignment.id,
					},
					data: {
						is_active: false,
					},
				});

                const newgeofence = await prismaClient.geofence_assignment.create({
					data: {
						vehicle_id: inputs.value.vehicle_id,
						geofence_id: inputs.value.geofence_id,
						is_active: inputs.value.is_active,
					},
					include: {
						geofences: true,
						vehicles: true,
					},
				});

				// Return success response
				return Response.ok(ctx, {
					code: 200,
					msg: 'Geofence assignment created successfully',
					data: newgeofence,
				});
			} else {
				// Create new geofence_assignment
				const newgeofence = await prismaClient.geofence_assignment.create({
					data: {
						vehicle_id: inputs.value.vehicle_id,
						geofence_id: inputs.value.geofence_id,
						is_active: inputs.value.is_active,
					},
					include: {
						geofences: true,
						vehicles: true,
					},
				});
				//--------------------------------------

				// // const check =
				// await prismaClient.geofence_assignment.update({
				// 	where: {
				// 		 geofence_id: parseInt(inputs.value.geofence_id),
				// 		vehicle_id: parseInt(inputs.value.vehicle_id),
				// 	},
				// 	data: {
				// 		is_active: false,
				// 	},
				// });

				//-------------------------------------

				// if (check) {
				//     return Response.error(ctx, {
				//         code: 50,
				//         msg: 'assignment with same details already present',
				//         data: check
				//     });
				// }
				// const { vehicle_id, geofence_id, is_active } = ctx.request.body
				// Create new
				// const newgeofence = await prismaClient.geofence_assignment.create({
				// 	data: {
				// 		vehicle_id: inputs.value.vehicle_id,
				// 		geofence_id: inputs.value.geofence_id,
				// 		is_active: inputs.value.is_active,
				// 	},
				// 	include: {
				// 		geofences: true,
				// 		vehicles: true,
				// 	},
				// });

				// Return success responseS
				return Response.created(ctx, {
					code: 200,
					msg: ' created successfully',
					data: newgeofence,
					include: {
						geofences: true,
						vehicles: true,
					},
				});
			}
		} catch (error) {
			console.log(error);
			return Response.internalServerError(ctx, {
				code: 500,
				msg: 'Internal Server Error',
				error: error,
			});
		}
	}
	static async getGeofenceAssignmentById(ctx) {
		try {
			const id = parseInt(ctx.params.id);
			const geofence = await prismaClient.geofence_assignment.findFirst({
				where: { id },
			});
			if (!geofence) {
				return Response.notFound(ctx, {
					code: 404,
					msg: 'Geofence not found',
				});
			}
			return Response.ok(ctx, {
				code: 200,
				msg: 'Success',
				data: geofence,
			});
		} catch (error) {
			console.log(error);
			return Response.internalServerError(ctx, {
				code: 500,
				msg: 'Internal Server Error',
			});
		}
	}

	static async getAllgeofenceAssignment(ctx) {
		try {
			const limit = +ctx.request.query.limit || 5;
			const offset = +ctx.request.query.offset || 0;
			const List = await prismaClient.geofence_assignment.findMany({
				skip: offset,
				take: limit,
			});
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'successful',
				data: List,
				count: List.count,
			});
		} catch (err) {
			return Response.success(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting geofence',
				error: err,
			});
		}
	}

	static async updateAssignmentById(ctx) {
		try {
			const id = parseInt(ctx.params.id);
			const existingid = await prismaClient.geofence_assignment.findFirst({
				where: { id },
			});
			if (!existingid) {
				return Response.notFound(ctx, {
					code: 404,
					msg: 'not found',
				});
			}
			const schema = Joi.object({
				vehicle_id: Joi.number(),
				geofence_id: Joi.number(),
				is_active: Joi.boolean(),
			});
			const inputs = await schema.validate(ctx.request.body);
			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 400,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			const updatedVehicle = await prismaClient.geofence_assignment.update({
				where: { id },
				data: {
					vehicle_id: inputs.value.vehicle_id,
					geofence_id: inputs.value.geofence_id,
					is_active: inputs.value.is_active,
				},
			});
			return Response.ok(ctx, {
				code: 200,
				msg: 'updated successfully',
				data: updatedVehicle,
			});
		} catch (error) {
			console.log(error);
			return Response.internalServerError(ctx, {
				code: 500,
				msg: 'Internal Server Error',
			});
		}
	}
};

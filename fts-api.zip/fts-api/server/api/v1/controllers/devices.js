/* eslint-disable indent */
'use strict';

// Import Prisma Client
const prismaClient = require('../utils/prisma.client');

// Import Response Util
const Response = require('../utils/response');

module.exports = class devicescontroller {
    constructor() { }

    static async getUnasiggnedDevices(ctx) {
        try {
            // console.log("11111")
            const limit = +ctx.request.query.limit || 10;
            const offset = +ctx.request.query.offset || 0;

            const devices = await prismaClient.devices.findMany({
                where: {
                    vehicle_id: null,
                },
                take : limit , 
                skip : offset,
                select: {
                    device_types: {
                        select: {
                            id: true,
                            static_name: true,
                            name: true
                        }
                    },
                    vehicles: {
                        select: {
                            id: true,
                            vehicle_no: true,
                            name: true
                        },
                    },
                    battery_level: true,
                    name :true,
                    id: true,
                    uid: true,
                    is_active: true,
                    // location: true,
                    is_connected: true,
                    last_data_at: true,
                    is_online: true,
                    is_moving: true,
                    created_at: true,
                    updated_at: true,
                    tempar_status: true,
                    vehicle_id: true,
                }
            });
            // const totalCount = await prismaClient.devices.count();
            return Response.success(ctx, {
                statusCode: 200,
                code: 200,
                msg: 'get devices successful',
                data: devices,
                count: devices.length
            });
        } catch (error) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 500,
                msg: 'Error getting devices',
            });
        }
    }

    static async getDevices(ctx) {
        try {
            // console.log("11111")
            const devices = await prismaClient.devices.findMany({
                select: {
                    device_types: {
                        select: {
                            id: true,
                            static_name: true,
                            name: true
                        }
                    },
                    vehicles: {
                        select: {
                            id: true,
                            vehicle_no: true,
                            name: true
                        },
                    },
                    battery_level: true,
                    id: true,
                    uid: true,
                    is_active: true,
                    name: true,
                    lat: true,
                    lng: true,
                    vehicle_assignments: true,
                    // location: true,
                    is_connected: true,
                    last_data_at: true,
                    is_online: true,
                    is_moving: true,
                    created_at: true,
                    updated_at: true,
                    tempar_status: true,
                    vehicle_id: true,
                    // vehicle_assignments: {
                    //     select: {
                    //         drivers: {
                    //             select: {
                    //                 id: true,
                    //                 name: true,
                    //                 id_card_no: true
                    //             }
                    //         }
                    //     }
                    // }
                }
            });
            const totalCount = await prismaClient.devices.count();
            return Response.success(ctx, {
                statusCode: 200,
                code: 200,
                msg: 'get devices successful',
                data: devices,
                count: totalCount
            });
        } catch (error) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 500,
                msg: 'Error getting devices',
            });
        }
    }
};
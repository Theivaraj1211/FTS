/* eslint-disable indent */
'use strict';
//prisma client
const prismaClient = require('../utils/prisma.client');
// Import Settings
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');
// Parse BigInt

// User Controller
module.exports = class DriverController {
    constructor() { }
    //get driver by id controller
    static async getDriversByID(ctx) {
        if (!ctx.request.query.id) {
            return Response.badRequest(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Id not passed pls select id',
            });
        }
        try {
            const output = await prismaClient.drivers.findUnique({
                where: {
                    id: parseInt(ctx.request.query.id),
                },
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'get Drivers successful',
                data: output,
                code: 20,
            });
        } catch (err) {
            console.log(err);
        }
    }

    //get driver by id controller
    static async getDrivers(ctx) {
        try {
            const limit = ctx.request.query.limit || 10;
            const offset = ctx.request.query.offset || 0;
            const search = ctx.request.query.search;
            // console.log(limit, offset);
            var output;
            var totalCount;
            // console.log(search.length);
            if (search != 0 && search != undefined) {
                console.log(
                    '_----------------------------------------------------------------------------------'
                );
                console.log(1);
                await prismaClient.drivers
                    .findMany({
                        orderBy: {
                            updated_at: 'desc',
                        },
                        where: {
                            driver_name: {
                                contains: search,
                                mode: 'insensitive',
                            },
                        },
                        skip: parseInt(offset),
                        take: parseInt(limit),
                        select: {
                            images: true,
                            blood_group: true,
                            city: true,
                            created_at: true,
                            updated_at: true,
                            dob: true,
                            driver_address: true,
                            driver_phone_no: true,
                            driver_name: true,
                            is_active: true,
                            emergency_mobile_no: true,
                            employee: true,
                            id: true,
                            email: true,
                            alerts: true,
                            id_card_no: true,
                            vehicle_assignments: {
                                include: {
                                    vehicles: true
                                }
                            },
                            license_no: true,
                            license_validity: true,
                            // vehicle_id : true
                        },
                    })
                    .then(async (d) => {
                        output = d;
                        totalCount = d.length;
                        for (var i = 0; i < d.length; i++) {
                            if (d[i].id) {
                                const vehicleDetails = await prismaClient.vehicle_assignments.findFirst({
                                    where: {
                                        driver_id: d[i].id,
                                    },
                                    select: {
                                        vehicles: true
                                    }
                                });
                                let vehicle = vehicleDetails.vehicles || null;
                                // if(vehicleDetails.vehicles != null || undefined){
                                output[i].vehicle = vehicle || undefined;
                                // }
                                // console.log(output[i].vehicle);
                            }
                        }
                        // d.map(async (item, index) => {
                        //     if (item.vehicle_id) {
                        //         const vehicleDetails = await prismaClient.vehicles.findFirst({
                        //             where: {
                        //                 id: item.vehicle_id
                        //             }
                        //         });
                        //         output[index].vehicle = vehicleDetails;
                        //         console.log(output[index].vehicle);
                        //     }
                        // });
                    });
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Drivers successful',
                    count: output.length,
                    data: output,
                    code: 20,
                });
            } else {
                console.log('_____________________________________________________');
                await prismaClient.drivers
                    .findMany({
                        skip: parseInt(offset),
                        take: parseInt(limit),
                        orderBy: {
                            updated_at: 'desc',
                        },
                        select: {
                            images: true,
                            blood_group: true,
                            city: true,
                            created_at: true,
                            updated_at: true,
                            dob: true,
                            driver_address: true,
                            driver_phone_no: true,
                            driver_name: true,
                            is_active: true,
                            emergency_mobile_no: true,
                            employee: true,
                            id: true,
                            email: true,
                            alerts: true,
                            id_card_no: true,
                            vehicle_assignments: {
                                include: {
                                    vehicles: true
                                }
                            },
                            license_no: true,
                            license_validity: true,
                            // vehicle_id: true,
                        },
                    })
                    .then(async (d) => {
                        output = d;
                        totalCount = await prismaClient.drivers.count();
                        for (var i = 0; i < d.length; i++) {
                            if (d[i].id) {
                                const vehicleDetails = await prismaClient.vehicle_assignments.findFirst({
                                    where: {
                                        driver_id: d[i].id,
                                    },
                                    select: {
                                        vehicles: true
                                    }
                                });
                                let vehicle = vehicleDetails.vehicles || null;
                                // if(vehicleDetails.vehicles != null || undefined){
                                output[i].vehicle = vehicle || undefined;
                            }
                        }
                    });
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'get Drivers successful',
                    count: totalCount,
                    data: output,
                    code: 20,
                });
            }
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting drivers',
                error: err,
            });
        }
    }
    static async deleteDriver(ctx) {
        if (!ctx.request.query.id) {
            return Response.badRequest(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Id not passed pls select id',
            });
        }
        try {
            const deletedDriver = await prismaClient.drivers.delete({
                where: {
                    id: parseInt(ctx.request.query.id),
                },
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'Driver Deleted',
                data: deletedDriver,
            });
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error deleting driver',
                error: err,
            });
        }
    }
    // update driver
    static async updateDriver(ctx) {
        if (!ctx.request.query.id) {
            return Response.badRequest(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Id not passed pls select id',
            });
        }
        try {
            // Input validation
            const schema = Joi.object({
                dob: Joi.date(),
                city: Joi.string(),
                employee: Joi.string(),
                driver_phone_no: Joi.string().min(6).max(12),
                license_validity: Joi.date(),
                id_card_no: Joi.string(),
                blood_group: Joi.string(),
                license_no: Joi.string(),
                images: Joi.array().min(0).max(5),
                emergency_mobile_no: Joi.string().min(6).max(12),
                driver_address: Joi.string(),
                email: Joi.string().email(),
                driver_name: Joi.string(),
                is_active: Joi.boolean(),
                vehicle_id: Joi.number(),
            });
            // Validate
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }

            // Check if user exists locally
            try {
                var output = await prismaClient.drivers.findUnique({
                    where: {
                        id: parseInt(ctx.request.query.id),
                    },
                });
                if (!output) {
                    return Response.success(ctx, {
                        statusCode: 500,
                        msg: 'driver not found',
                    });
                }
                // const driverReturns = await prismaClient.drivers.findFirst({
                //     where: {
                //         OR: [
                //             { license_no: inputs.value.license_no },
                //             { driver_phone_no: inputs.value.driver_phone_no },
                //             { id_card_no: inputs.value.id_card_no },
                //             { emergency_mobile_no: inputs.value.emergency_mobile_no },
                //         ]
                //     },
                    // include : {
                    //     vehicle_assignments : {
                    //         include : {
                    //             devices : true
                    //         }
                    //     }
                    // }
                // });
                // console.log(driverReturns);
                // if (driverReturns) {
                //     if (driverReturns.driver_phone_no == inputs.value.driver_phone_no) {
                //         return Response.success(ctx, {
                //             code: 41,
                //             msg: 'Driver already registered with same phone number !',
                //         });
                //     }
                //     if (driverReturns.license_no == inputs.value.license_no) {
                //         return Response.success(ctx, {
                //             code: 41,
                //             msg: 'Driver already registered with same license number !',
                //         });
                //     }
                //     if (driverReturns.id_card_no == inputs.value.id_card_no) {
                //         return Response.success(ctx, {
                //             code: 41,
                //             msg: 'Driver already registered with same id card number number !',
                //         });
                //     }
                //     if (driverReturns.email == inputs.value.email) {
                //         return Response.success(ctx, {
                //             code: 41,
                //             msg: 'Driver already registered with same email !',
                //         });
                //     }
                //     if (driverReturns.emergency_mobile_no == inputs.value.emergency_mobile_no) {
                //         return Response.success(ctx, {
                //             code: 41,
                //             msg: 'Driver already registered with same emergency_mobile_no !',
                //         });
                //     }
                // }
                const assignment_id = await prismaClient.vehicle_assignments.findFirst({
                    where: {
                        driver_id: parseInt(ctx.request.query.id)
                    }
                });
                var assignment ;
                // if (inputs.value.vehicle_id != undefined || null && inputs.value.vehicle_id != assignment_id.vehicle_id) {
                //     console.log('-----------------------------------------');
                //     // var assignment;
                //     if (!assignment_id) {
                //         const vehicle = await prismaClient.vehicle_assignments.findFirst({
                //             where: {
                //                 driver_id: ctx.request.query.id
                //             },
                //             select: {
                //                 vehicles: true
                //             }
                //         });
                //         assignment = await prismaClient.vehicle_assignments.create({
                //             data: {
                //                 device_id: vehicle.vehicles.device_id,
                //                 vehicle_id: ctx.request.body.vehicle_id,
                //                 driver_id: ctx.request.query.id,
                //             },
                //         });
                //     } else {
                //         console.log(assignment_id.id);
                //         const vehicle = await prismaClient.vehicle_assignments.findFirst({
                //             where: {
                //                 driver_id: parseInt(ctx.request.query.id)
                //             },
                //             select: {
                //                 vehicles: true
                //             }
                //         });
                //         assignment = await prismaClient.vehicle_assignments.update({
                //             where: {
                //                 id: assignment_id.id
                //             },
                //             data: {
                //                 vehicle_id: ctx.request.body.vehicle_id,
                //                 device_id: vehicle.vehicles.device_id
                //             }
                //         });
                //     }
                // }
                if (inputs.value.vehicle_id != undefined || null && inputs.value.vehicle_id != assignment_id.vehicle_id) {
                    const vehicle = await prismaClient.vehicle_assignments.findFirst({
                        where: {
                            driver_id: parseInt(ctx.request.query.id)
                        },
                        select: {
                            vehicles: true
                        }
                    });
                    assignment = await prismaClient.vehicle_assignments.update({
                        where: {
                            id: assignment_id.id
                        },
                        data: {
                            vehicle_id: ctx.request.body.vehicle_id,
                            device_id: vehicle.vehicles.device_id
                        }
                    });
                }
                delete inputs.value.vehicle_id ;
                inputs.value.email == output.email ? delete inputs.value.email : null ;
                var updateOutput = await prismaClient.drivers.update({
                    where: {
                        id: parseInt(ctx.request.query.id),
                    },
                    data: inputs.value,
                });
                updateOutput.assignment = assignment;
                return Response.success(ctx, {
                    statusCode: 200,
                    msg: 'driver updated',
                    data: updateOutput,
                });
            } catch (err) {
                console.log(err);
                return Response.error(ctx, {
                    statusCode: 500,
                    code: 50,
                    msg: 'Internal Error could not update driver',
                    error: err,
                });
            }
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Internal Error',
                error: err,
            });
        }
    }
    //delete driver
    static async createDriver(ctx) {
        try {
            // Input validation
            const schema = Joi.object({
                dob: Joi.date().required(),
                city: Joi.string().required(),
                employee: Joi.string().required(),
                driver_phone_no: Joi.string().min(6).max(12).required(),
                license_validity: Joi.date(),
                id_card_no: Joi.string().required(),
                blood_group: Joi.string().required(),
                license_no: Joi.string().required(),
                images: Joi.array().max(3).min(0),
                emergency_mobile_no: Joi.string().required().min(6).max(12),
                driver_address: Joi.string().required(),
                email: Joi.string().email().required(),
                driver_name: Joi.string().required(),
                vehicle_id: Joi.number(),
            });
            // Validate
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }
            // Check if user exists
            const driverReturn = await prismaClient.drivers.findFirst({
                where: {
                    OR: [
                        { email: inputs.value.email },
                        { license_no: inputs.value.license_no },
                        { driver_phone_no: inputs.value.driver_phone_no },
                        { id_card_no: inputs.value.id_card_no },
                        { emergency_mobile_no: inputs.value.emergency_mobile_no },
                    ],
                },
            });
            // const checkDriver = await ParseBigInt(driverReturn);
            try {
                // If exists return
                console.log(driverReturn);
                if (driverReturn) {
                    if (driverReturn.driver_phone_no == inputs.value.driver_phone_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'Driver already registered with same phone number !',
                            msg: 'Driver already registered with same phone number !',
                        });
                    }
                    if (driverReturn.license_no == inputs.value.license_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'Driver already registered with same license number !',
                            msg: 'Driver already registered with same license number !',
                        });
                    }
                    if (driverReturn.id_card_no == inputs.value.id_card_no) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'Driver already registered with same id card number !',
                            msg: 'Driver already registered with same id card number number !',
                        });
                    }
                    if (driverReturn.email == inputs.value.email) {
                        return Response.success(ctx, {
                            code: 41,
                            error: 'Driver already registered with same email !',
                            msg: 'Driver already registered with same email !',
                        });
                    }
                    if (
                        driverReturn.emergency_mobile_no == inputs.value.emergency_mobile_no
                    ) {
                        return Response.success(ctx, {
                            code: 41,
                            error:
                                'Driver already registered with same emergency_mobile_no !',
                            msg: 'Driver already registered with same emergency_mobile_no !',
                        });
                    }
                }
                // if (checkDriver) {
                //     return Response.success(ctx, {
                //         statusCode: 500,
                //         code: 20,
                //         msg: 'Driver already registered !',
                //     });
                // }
                const vehicleID = inputs.value.vehicle_id ; 
                console.log(vehicleID);
                delete inputs.value.vehicle_id ; 
                await prismaClient.drivers
                    .create({
                        data: inputs.value,
                    })
                    .catch((e) => {
                        console.log(e);
                        return Response.error(ctx, {
                            statusCode: 500,
                            code: 51,
                            msg: 'error creating driver',
                            error: e,
                        });
                    })
                    .then(async (value) => {
                        await prismaClient.vehicles
                            .findFirst({
                                where: {
                                    id: vehicleID,
                                },
                            })
                            .then(async (d) => {
                                await prismaClient.vehicle_assignments
                                    .create({
                                        data: {
                                            device_id: d.device_id,
                                            driver_id: value.id,
                                            vehicle_id: d.id,
                                        },
                                    })
                                    .catch((e) => {
                                        console.log(e);
                                        console.log(d.device_id, value.id, d.id);
                                    })
                                    .then((assignments) => {
                                        value.vehicle_assignments = assignments;
                                        return Response.success(ctx, {
                                            statusCode: 201,
                                            code: 20,
                                            msg: 'Driver created with assignment!',
                                            data: value,
                                            count: value.count,
                                        });
                                    });
                            });
                    });
            } catch (err) {
                return Response.error(ctx, {
                    statusCode: 500,
                    code: 51,
                    msg: 'Internal Error',
                    error: err,
                });
            }
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Internal Error In check user',
                error: err,
            });
        }
    }
};

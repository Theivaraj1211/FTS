/* eslint-disable indent */
'use strict';

// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class geofencecontroller {
    constructor() { }
    // static async SearchGeofences(ctx) {
    //     try {
    //         const schema = Joi.object({
    //             name: Joi.string().required() ,
    //             limit : Joi.number(),
    //             offset : Joi.number()
    //         });
    //         const inputs = schema.validate(ctx.request.query);
    //         if (inputs.error) {
    //             console.log(inputs.error);
    //             return Response.badRequest(ctx, {
    //                 code: 40,
    //                 msg: 'Please provide valid data  !!',
    //                 error: inputs.error.details,
    //             });
    //         }
    //         console.log(inputs.value.name);
    //         const limit = +ctx.request.query.limit || 5;
    //         const offset = +ctx.request.query.offset || 0;
    //         const d = await prismaClient.$queryRaw` SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from geofences where name like ${inputs.value.name+'%'} limit ${limit} offset ${offset}  `;
    //             console.log(d);
    //             return Response.success(ctx, {
    //                 code: 40,
    //                 msg: 'route search successful !!', 
    //                 data: d,
    //                 count : d.length
    //             });          
    //     } catch (error) {
    //         console.log(error);
    //         return Response.error(ctx, {
    //             code: 40,
    //             msg: 'unable to search routes !',
    //             error: error,
    //         });
    //     }
    // }
    static async deleteGeofence(ctx) {
        try {
            const checkGeofence = await prismaClient.geofences.findFirst({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            if (!checkGeofence) {
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'geofence not found',
                });
            }
            const result = await prismaClient.geofences.delete({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            return Response.success(ctx, {
                code: 40,
                msg: 'geofence deleted !',
                data: result,
            });
        } catch (error) {
            console.log(error);
            return Response.error(ctx, {
                code: 40,
                msg: 'unable to delete geofence !',
                error: error,
            });
        }
    }
    static async creategeofence(ctx) {
        try {
            // Get Input
            const schema = Joi.object({
                name: Joi.string().required(),
                coordinates: Joi.array()
                    .items(
                        Joi.array()
                            .items(Joi.number().required(), Joi.number().required())
                            .length(2)
                            .required()
                    ),
                is_active: Joi.boolean().default(true),
                main_location : Joi.string().required()
            });
            const inputs =  schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }
            const namealready = await prismaClient.geofences.findFirst({
                where: { name: inputs.value.name }
            });
            if (namealready) {
                return Response.conflict(ctx, {
                    code: 409,
                    msg: 'name already exists in the database',
                });
            }
            const { name, coordinates, is_active,main_location } = inputs.value;
            // Create new 
            // const newgeofence = await prismaClient.$queryRawUnsafe(`INSERT INTO geofences (name,coordinates)
            // VALUES ('${name}','SRID=4326;POINT(${long} ${lat})')`)
            const coordinates1 = JSON.stringify({
                type: 'Polygon',
                coordinates: [coordinates],
            });
            await prismaClient.$queryRawUnsafe(
                ` INSERT INTO geofences (name,main_location,is_active, coordinates) VALUES ('${name}','${main_location},'${is_active}',ST_GeomFromGeoJSON('${coordinates1}'::json));`
            );
            // Return success responseS
            return Response.created(ctx, {
                code: 200,
                msg: ' created successfully',
                data: inputs.value
            });

        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }


    static async updateById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const nameisalready = await prismaClient.geofences.findFirst({
                where: { id }
            });
            if (!nameisalready) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'data not found'
                });
            }
            const schema = Joi.object({
                name: Joi.string(),
                coordinates: Joi.array()
                    .items(
                        Joi.array()
                            .items(Joi.number().required(), Joi.number())
                            .length(2)
                            .required()
                    ),
                is_active: Joi.boolean().default(true),
                main_location : Joi.string(),
                is_active_toggle: Joi.boolean()

            });
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 400,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details
                });
            }
            const { coordinates, is_active, name,main_location } = inputs.value;
            console.log(is_active);
            const coordinates_polygon = JSON.stringify({
                type: 'Polygon',
                coordinates: [coordinates],
            });
            console.log(coordinates, is_active,main_location, name);
            // if (ctx.request.body.is_active_toggle != undefined) {
            //     // console.log('1');
            //     const name_coordinate = ` geofences SET is_active = ${inputs.value.is_active_toggle} WHERE id = ${id}`;
            //     console.log(name_coordinate);
            //     await prismaClient.$` UPDATE ${name_coordinate}`;
            // }
            // else  {
            //     console.log(2);
            //     // const name_coordinate = ` update  geofences set "name" = ${name} , is_active = ${is_active}, coordinates = ST_GeomFromGeoJSON('${coordinates_polygon}') WHERE id = ${id}`;
            //     console.log(`update  geofences set "name" = ${name} , is_active = ${is_active}, coordinates = ST_GeomFromGeoJSON('${coordinates_polygon}'::json) WHERE id = ${id}`);
            //     await prismaClient.$executeRaw ` update  geofences set "name" = '${name}' , is_active = ${is_active}, coordinates = ST_GeomFromGeoJSON('${coordinates_polygon}') WHERE id = ${id}`;
            // } 
            if (ctx.request.body.is_active_toggle != undefined) {

                console.log('1');

                const name_coordinate = ` geofences SET is_active = ${inputs.value.is_active_toggle} WHERE id = ${id}`;

                console.log(name_coordinate);

                await prismaClient.$queryRawUnsafe(` UPDATE ${name_coordinate}`);

            } else {

                console.log(2);

                const name_coordinate = `geofences SET "name" = '${name}',main_location = '${main_location}',coordinates = ST_GeomFromGeoJSON('${coordinates_polygon}'::json) WHERE id = ${id}`;

                console.log(name_coordinate);

                await prismaClient.$queryRawUnsafe(` UPDATE ${name_coordinate}`);

            }
            return Response.ok(ctx, {
                code: 200,
                msg: ' updated successfully',
                data: inputs.value
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                err: error,
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }




    static async getGeofenceById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const geofence = await prismaClient.geofences.findFirst({ where: { id } });
            if (!geofence) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'Geofence not found'
                });
            }
            return Response.ok(ctx, {
                code: 200,
                msg: 'Success',
                data: geofence
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }



    static async getAllgeofence(ctx) {
        try {
            // const schema = Joi.object({
            //     search: Joi.string() ,
            //     limit : Joi.number(),
            //     offset : Joi.number()
            // });
            // const inputs = schema.validate(ctx.request.query);
            // if (inputs.error) {
            //     console.log(inputs.error);
            //     return Response.badRequest(ctx, {
            //         code: 40,
            //         msg: 'Please provide valid data  !!',
            //         error: inputs.error.details,
            //     });
            // }

            const limit = +ctx.request.query.limit || 10;
            const offset = +ctx.request.query.offset || 0;
            const search = ctx.request.query.search;
            // const list = await prismaClient.$queryRaw` select * from geofences g limit ${limit} offset ${offset}`;
            var list;
            var totalCount ;
            if (search == 0 || search == undefined || search == null) {
                console.log(`SELECT ST_AsGeoJSON(coordinates)::json,"name",main_location ,id ,is_active, created_at , updated_at  from geofences g limit ${limit} offset ${offset} orderBy updated_at desc`);
                list = await prismaClient.$queryRaw`SELECT ST_AsGeoJSON(coordinates)::json,"name",main_location ,id ,is_active, created_at , updated_at  from geofences g order by updated_at desc limit  ${limit} offset ${offset}`;
                totalCount  =  await prismaClient.geofences.count();
            } else {
                console.log('object');
                console.log(ctx.request.query.search);
                // const search = search+'%';
                console.log(search);
                // console.log(`SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from geofences g where name like '${search}' limit ${limit} offset ${offset}`);
                list = await prismaClient.$queryRaw` SELECT ST_AsGeoJSON(coordinates)::json,id,"name",main_location ,is_active , created_at , updated_at from geofences where name ilike ${search + '%'} or id = ${parseInt(search)} order by updated_at desc limit ${limit} offset ${offset} `;
                totalCount = list.length ;
            }
            // const list = await prismaClient.$queryRaw`${url}`;
            // const totalCount = await prismaClient.geofences.count(); 
            // console.log(list);
            // if(list[0] == undefined){
            //     list = await prismaClient.$queryRaw`SELECT ST_AsGeoJSON(coordinates)::json,"name" ,id ,is_active, created_at  from geofences g limit ${limit} offset ${offset}`;
            // }
            return Response.success(ctx, {
                code: 20,
                msg: 'successful',
                data: list,
                count: totalCount
            });
        } catch (err) {
            console.log(err);
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting geofence',
                error: err
            });
        }
    }
};
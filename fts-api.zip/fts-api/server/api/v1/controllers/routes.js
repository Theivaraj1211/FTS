/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');
// Parse BigInt
// Get Country code Id of a country
// Twilio package for sending message
module.exports = class routescontroller {

    constructor() { }

    static async SearchRoutes(ctx) {
        try {
            const schema = Joi.object({
                name: Joi.string().required() ,
                limit : Joi.number(),
                offset : Joi.number()
            });
            const inputs = schema.validate(ctx.request.query);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data  !!',
                    error: inputs.error.details,
                });
            }
            console.log(inputs.value.name);
            const limit = +ctx.request.query.limit || 5;
            const offset = +ctx.request.query.offset || 0;
            const d = await prismaClient.$queryRaw` SELECT coordinates,id,"name" ,is_active , created_at , updated_at from routes where name like ${inputs.value.name+'%'} limit ${limit} offset ${offset}  `;
                console.log(d);
                return Response.success(ctx, {
                    code: 40,
                    msg: 'route search successful !!', 
                    data: d,
                    count : d.length
                });          
        } catch (error) {
            console.log(error);
            return Response.error(ctx, {
                code: 40,
                msg: 'unable to search routes !',
                error: error,
            });
        }
    }
    static async deleteRoute(ctx) {
        try {
            const checkRoute = await prismaClient.routes.findFirst({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            if (!checkRoute) {
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'route not found',
                });
            }
            const result = await prismaClient.routes.delete({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            return Response.success(ctx, {
                code: 40,
                msg: 'route deleted !',
                data: result,
            });
        } catch (error) {
            console.log(error);
            return Response.error(ctx, {
                code: 40,
                msg: 'unable to delete routes !',
                error: error,
            });
        }
    }

    static async createroutes(ctx) {
        try {
            // Get Input
            const schema = Joi.object({
                name: Joi.string(),
                coordinates: Joi.array()
                    .items(
                        Joi.array()
                            .items(Joi.number().required(), Joi.number().required())
                            .length(2)
                            .required()
                    ),
                    main_location : Joi.string(),
                is_active: Joi.boolean().default(true)
            });
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }
            const namealready = await prismaClient.routes.findFirst({
                where: { name: inputs.value.name }
            });
            if (namealready) {
                return Response.conflict(ctx, {
                    code: 409,
                    msg: 'route name already exists in the database',
                });
            }
            const { name, main_location,coordinates, is_active } = inputs.value;
            const routes_json = JSON.stringify({
                type: 'LineString',
                coordinates: coordinates,
            });
            
            console.log( ` 
            INSERT INTO routes (name,is_active, coordinates) VALUES ('${name}',${is_active},${routes_json});`);
            const newroutes = await prismaClient.$queryRawUnsafe(
                ` 
                INSERT INTO routes (name,main_location,is_active, coordinates) VALUES ('${name}','${main_location}',${is_active},'${routes_json}');`
            );
            
            return Response.created(ctx, {
                code: 200,
                msg: ' created route successfully',
                data: inputs.value
            });

        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error',
                error: error
            });
        }
    }

    static async updateById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const nameisalready = await prismaClient.routes.findFirst({
                where: { id }
            });
            if (!nameisalready) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'data not found'
                });
            }
            const schema = Joi.object({
                name: Joi.string(),
                coordinates: Joi.array()
                    .items(
                        Joi.array()
                            .items(Joi.number().required(), Joi.number().required())
                            .length(2)
                            .required()
                    ),
                main_location : Joi.string(),
                is_active: Joi.boolean(),
                is_active_toggle: Joi.boolean()

            });
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 400,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details
                });
            }

            const { coordinates,main_location, name, is_active, is_active_toggle } = ctx.request.body;
            const coordinates_polygon = JSON.stringify({
                type: 'LineString',
                coordinates: coordinates,
            });
            if (is_active_toggle != undefined) {
                await prismaClient.$queryRawUnsafe(` UPDATE routes SET is_active = ${is_active_toggle}  WHERE id = ${id}`);

            } else {
                await prismaClient.$queryRawUnsafe(` UPDATE routes SET coordinates = '${coordinates_polygon}' , name = '${name}',main_location = '${main_location}' , is_active = ${is_active} WHERE id = ${id}`);
            }
            return Response.ok(ctx, {
                code: 200,
                msg: ' updated successfully',
                data: inputs.value
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }

    static async getRoutesById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const routes = await prismaClient.routes.findFirst({ where: { id } });
            if (!routes) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: ' not found'
                });
            }
            return Response.ok(ctx, {
                code: 200,
                msg: 'Success',
                data: routes
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }

    static async getAllRoutes(ctx) {
        try {
            // const schema = Joi.object({
            //     search: Joi.string() ,
            //     limit : Joi.number(),
            //     offset : Joi.number()
            // });
            // const inputs = schema.validate(ctx.request.query);
            // if (inputs.error) {
            //     console.log(inputs.error);
            //     return Response.badRequest(ctx, {
            //         code: 40,
            //         msg: 'Please provide valid data  !!',
            //         error: inputs.error.details,
            //     });
            // }
    
            const limit = +ctx.request.query.limit || 10;
            const offset = +ctx.request.query.offset || 0;
            const search = ctx.request.query.search ; 
            var list ;
            var count ;

            if(search == 0 || search == undefined || search == null){
                console.log('1');
                list = await prismaClient.$queryRaw`SELECT coordinates,"name",main_location ,id ,is_active, created_at,updated_at  from routes r order by updated_at desc limit ${limit} offset ${offset}`;
                count = await prismaClient.routes.count() ;
            }else{
                console.log('object');
                // console.log(ctx.request.query.search);
                // const search = search+'%';
                console.log(search);
                console.log(` SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from routes g where name like '${search}' limit ${limit} offset ${offset}`);
                list = await prismaClient.$queryRaw` SELECT coordinates,id,"name",main_location ,is_active , created_at , updated_at from routes  where name ilike ${search+'%'}  order by updated_at desc limit ${limit} offset ${offset}  `;
                count = list.length ; 
            }
            // const list = await prismaClient.$queryRaw`${url}`;
            // const totalCount = await prismaClient.geofences.count();
            console.log(list);
            // if(list[0] == undefined){
            //     list = await prismaClient.$queryRaw`SELECT ST_AsGeoJSON(coordinates)::json,"name" ,id ,is_active, created_at  from routes g limit ${limit} offset ${offset}`;
            // }
            
            
            // list = await prismaClient.$queryRaw` SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from routes limit ${limit} offset ${offset} `;
            // const totalCount = await prismaClient.routes.count();
            return Response.success(ctx, {
                code: 20,
                msg: 'successful',
                data: list
                , count: count
            });

        } catch (err) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting routes',
                error: err
            });
        }
    }



static async getGeofenceById(ctx) {
    try {
        const id = parseInt(ctx.params.id);
        const geofence = await prismaClient.geofences.findFirst({ where: { id } });
        if (!geofence) {
            return Response.notFound(ctx, {
                code: 404,
                msg: 'Geofence not found'
            });
        }
        return Response.ok(ctx, {
            code: 200,
            msg: 'Success',
            data: geofence
        });
    } catch (error) {
        console.log(error);
        return Response.internalServerError(ctx, {
            code: 500,
            msg: 'Internal Server Error'
        });
    }
}

};

// static async getAllgeofence(ctx) {
//     try {
//         const schema = Joi.object({
//             search: Joi.string() ,
//             limit : Joi.number(),
//             offset : Joi.number()
//         });
//         const inputs = schema.validate(ctx.request.query);
//         if (inputs.error) {
//             console.log(inputs.error);
//             return Response.badRequest(ctx, {
//                 code: 40,
//                 msg: 'Please provide valid data  !!',
//                 error: inputs.error.details,
//             });
//         }

//         const limit = +ctx.request.query.limit || 5;
//         const offset = +ctx.request.query.offset || 0;
//         // const list = await prismaClient.$queryRaw` select * from geofences g limit ${limit} offset ${offset}`;
//         var list ;
//         if(!ctx.request.query.search){
//             console.log('1');
//             list = await prismaClient.$queryRaw`SELECT ST_AsGeoJSON(coordinates)::json,"name" ,id ,is_active, created_at  from geofences g limit ${limit} offset ${offset}`;
//         }else{
//             console.log('object');
//             console.log(ctx.request.query.search);
//             const search = inputs.value.search+'%';
//             console.log(search);
//             console.log(`SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from geofences g where name like '${search}' limit ${limit} offset ${offset}`);
//             list = await prismaClient.$queryRaw` SELECT ST_AsGeoJSON(coordinates)::json,id,"name" ,is_active , created_at , updated_at from geofences where name like ${inputs.value.search+'%'} limit ${limit} offset ${offset}  `;
//         }
//         // const list = await prismaClient.$queryRaw`${url}`;
//         // const totalCount = await prismaClient.geofences.count();
//         console.log(list);
//         if(list[0] == undefined){
//             list = await prismaClient.$queryRaw`SELECT ST_AsGeoJSON(coordinates)::json,"name" ,id ,is_active, created_at  from geofences g limit ${limit} offset ${offset}`;
//         }
//         return Response.success(ctx, {
//             statusCode: 200,
//             msg: 'successful',
//             data: list,
//             count: list.length
//         });
//     } catch (err) {
//         console.log(err);
//         return Response.success(ctx, {
//             statusCode: 500,
//             code: 50,
//             msg: 'Error getting geofence',
//             error: err
//         });
//     }
// }
/* eslint-disable indent */
'use strict';
// Import Bcrypt

const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class routerAssignmentcontroller {
    constructor() { }
    // static async getVehicleStatus(ctx){
    //     try{
    //         const output = await prismaClient.vehicle_status.findMany();
    //         return Response.success(ctx, {
    //             statusCode: 200,
    //             msg: 'get successful',
    //             data: output
    //         });
    //     }catch(err){
    //         console.log(err);
    //          return Response.error(ctx, {
    //             statusCode: 500,
    //             code: 50,
    //             msg: 'Error getting data',
    //             error: err
    //         });
    //     }
    // }
    static async deleteRouteAssignment(ctx) {
        try {
            const deletedassignment = await prismaClient.route_assignments.delete({
                where: {
                    id: parseInt(ctx.params.id)
                }
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'route assignment Deleted',
                data: deletedassignment
            });
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error deleting route assignment please provide valid id',
                error: err
            });
        }
    }
    static async createrouterassignment(ctx) {
        try {
            // Get Input
            const schema = Joi.object({
                route_id: Joi.number().integer(),
                vehicle_id: Joi.number().integer(),
                vehicle_status_id: Joi.number().integer()

            })
            const inputs = await schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }

            const check = await prismaClient.route_assignments.findFirst({
                where: {
                    route_id: parseInt(inputs.value.route_id),
                    vehicle_id: parseInt(inputs.value.vehicle_id),
                }
            });
            if (check) {
                return Response.error(ctx, {
                    code: 50,
                    msg: 'assignment with same details already present',
                    data: check
                });
            }
            // Create new 
            const newrouter = await prismaClient.route_assignments.create({
                data: {
                    route_id: inputs.value.route_id,
                    vehicle_id: inputs.value.vehicle_id,
                },
                include: {
                    routes: true,
                    vehicles: true,
                },
            });

            // Return success responseS
            return Response.created(ctx, {
                code: 200,
                msg: 'assignment created successfully',
                data: newrouter,
                include: {
                    routes: true,
                    vehicles: true,
                },
            });

        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }

    static async getAllRoutesAssignment(ctx) {
        try {
            const limit = +ctx.request.query.limit || 5;
            const offset = +ctx.request.query.offset || 0;
            const List = await prismaClient.route_assignments.findMany({
                skip: offset,
                take: limit,
            });
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'successful',
                data: List,
                count: List.length
            });

        } catch (err) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting routes',
                error: err
            });
        }
    }
    static async getRoutesAssignmentById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const Routes = await prismaClient.route_assignments.findFirst({ where: { id } });
            if (!Routes) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: ' not found'
                });
            }
            return Response.ok(ctx, {
                code: 200,
                msg: 'Success',
                data: Routes,
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }


    static async updateRoutesAssignmentById(ctx) {
        try {
            const id = parseInt(ctx.params.id);
            const existingid = await prismaClient.route_assignments.findFirst({
                where: { id }
            });
            if (!existingid) {
                return Response.notFound(ctx, {
                    code: 404,
                    msg: 'not found'
                });
            }
            const schema = Joi.object({
                route_id: Joi.number().integer(),
                vehicle_id: Joi.number().integer(),
                vehicle_status_id: Joi.number().integer()
            })
            const inputs = await schema.validate(ctx.request.body);
            if (inputs.error) {
                console.log(inputs.error);
                return Response.badRequest(ctx, {
                    code: 400,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details
                });
            }
            const updated = await prismaClient.route_assignments.update({
                where: { id },
                data: {
                    route_id: inputs.value.route_id,
                    vehicle_id: inputs.value.vehicle_id
                },
            });
            return Response.ok(ctx, {
                code: 200,
                msg: 'updated successfully',
                data: updated
            });
        } catch (error) {
            console.log(error);
            return Response.internalServerError(ctx, {
                code: 500,
                msg: 'Internal Server Error'
            });
        }
    }



}
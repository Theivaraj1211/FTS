/* eslint-disable indent */
'use strict';
// Import JWT
const Jwt = require('jsonwebtoken');
// Import Bcrypt
const Bcrypt = require('bcrypt');
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import Settings
const { jwtSignature } = require('../../../config/adaptor');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');
// Parse BigInt
const ParseBigInt = require('../utils/parse.bigint');
// Get Country code Id of a country
const GetCountryCode = require('../utils/getcountry.code');
// Twilio package for sending message
const sendSms = require('../utils/send.sms');
// sending email
const sendEmail = require('../utils/emailHandler');
//Moment Js for Time
const Moment = require('moment');
const { date } = require('joi');
const { users } = require('../utils/prisma.client');
//email handler for send otp
//const sendEmail = require("../utils/send.email")

// User Controller
module.exports = class UserController {
	constructor() {}
	//User Search
	static async SearchUser(ctx) {
		try {
			const schema = Joi.object({
				search: Joi.string(),
				limit: Joi.number(),
				offset: Joi.number(),
			});
			const inputs = schema.validate(ctx.request.query);
			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data  !!',
					error: inputs.error.details,
				});
			}
			const limit = +ctx.request.query.limit || 5;
			const offset = +ctx.request.query.offset || 0;
			const d =
				await prismaClient.$queryRaw` SELECT * from users where name ILike ${
					inputs.value.search + '%'
				} limit ${limit} offset ${offset}  `;
			return Response.success(ctx, {
				code: 40,
				msg: 'user search successful !!',
				data: d,
				count: d.length,
			});
		} catch (error) {
			console.log(error);
			return Response.error(ctx, {
				code: 40,
				msg: 'unable to search users !',
				error: error,
			});
		}
	}
	// // 	//Web Signin
	//     // 	static async adminSignin(ctx) {
	//     // 		try {
	//     // 			// Input validation
	//     // 			const schema = Joi.object({
	//     // 				email: Joi.string().min(6).max(50).required(),
	//     // 				password: Joi.string().min(7).max(16).required(),
	//     // 			});
	//     // 			// Validate
	//     // 			const inputs = await schema.validate(ctx.request.body);

	//     // 			if (inputs.error) {
	//     // 				console.log(inputs.error);
	//     // 				return Response.badRequest(ctx, {
	//     // 					code: 40,
	//     // 					msg: 'Please provide valid data!',
	//     // 					error: inputs.error.details,
	//     // 				});
	//     // 			}
	//     // 			const {email,password}= ctx.request.body
	//     // 			// Check if user exists locally
	//     // 			const userReturn = await prismaClient.apps.findFirst({
	//     // 				where: {
	//     // 					email,
	//     // 					is_active: true,
	//     // 				}
	//     // 			});

	//     // 			const checkUser = await ParseBigInt(userReturn);

	//     // 			try {

	//     // 				// If exists
	//     // 				if (!checkUser) {
	//     // 					// Return
	//     // 					return Response.badRequest(ctx, {
	//     // 						statusCode: 400,
	//     // 						code: 40,
	//     // 						msg: 'User not found login!',
	//     // 					});
	//     // 				}
	//     // 				// Compare password
	//     // 				const passwordCheck = await Bcrypt.compareSync(
	//     // 					password,
	//     // 					checkUser.password
	//     // 				);
	//     // 				console.log(passwordCheck)
	//     // 				// Return
	//     // 				if (!passwordCheck) {
	//     // 					return Response.unauthorized(ctx, {
	//     // 						statusCode: 401,
	//     // 						code: 41,
	//     // 						msg: 'Password does not match!',
	//     // 					});
	//     // 				}

	//     // 				//Password Expiry Check
	//     // 				if (checkUser) {
	//     // 					const userPassReturn = await prismaClient.apps.findFirst({
	//     // 						where: {
	//     // 							email,
	//     // 							passwordexpirydate :{
	//     // 								gte : new Date().toISOString()
	//     // 							}
	//     // 						},
	//     // 						select : {
	//     // 							email: true,
	//     // 							passwordexpirydate : true,
	//     // 						}

	//     // 					});

	//     // 					const checkUserPasswordExpiry = await ParseBigInt(userPassReturn);
	//     // 					if(!checkUserPasswordExpiry){
	//     // 						return Response.badRequest(ctx, {
	//     // 							statusCode: 400,
	//     // 							code: 40,
	//     // 							msg: 'Password expired!',
	//     // 						});
	//     // 					}
	//     // 				}
	//     // //------------------------------------------------------------------------------------------------------------
	//     // 				console.log(checkUser)
	//     // 				// JWT generate - accessToken
	//     // 				const accessToken = Jwt.sign(
	//     // 					{
	//     // 						id: checkUser['id'],
	//     // 						email: checkUser['email'],
	//     // 						isActive: checkUser['is_active'],
	//     // 					},
	//     // 					jwtSignature.accessSecret,
	//     // 					{
	//     // 						expiresIn: '7d',
	//     // 					}
	//     // 				);
	//     // 				return Response.success(ctx, {
	//     // 					statusCode: 200,
	//     // 					code: 20,
	//     // 					msg: 'Successful login!',
	//     // 					data: {
	//     // 						id: checkUser.id,
	//     // 						name: checkUser['name'],
	//     // 						email: checkUser['email'],
	//     // 						token: accessToken,
	//     // 					}

	// 				});
	// 			} catch (err) {
	// 				console.log(err)
	// 				return Response.error(ctx, {
	// 					statusCode: 500,
	// 					code: 50,
	// 					msg: 'Internal Error',
	// 					error: err,
	// 				});
	// 			}
	// 		} catch (err) {
	// 			return Response.error(ctx, {
	// 				statusCode: 500,
	// 				code: 50,
	// 				msg: 'Internal Error In check user',
	// 				error: err,
	// 			});
	// 		}
	// 	}

	// All Roles
	static getAllRoles = async (ctx) => {
		try {
			const RolesList = await prismaClient.roles.findMany({
				select: {
					id: true,
					name: true,
					is_active: true,
				},
			});
			const count = await prismaClient.roles.count({});
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'Records Found',
				data: RolesList,
				count,
				code: 20,
			});
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting users',
				error: err,
			});
		}
	};
	// User Signup
	static signup = async (ctx) => {
		try {
			// Get Input
			const schema = Joi.object({
				// First name and last name should not contain any special characters
				name: Joi.string().min(1).max(40).required(),
				email: Joi.string().email().required(),
				mobile: Joi.string().min(6).max(12).required(),
				is_active: Joi.boolean(),
				role_id: Joi.number().required(),
				app_id: Joi.number(),

				// Password should atleast be a minimum 0f 8 characters and
				// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
				password: Joi.string()
					.min(8)
					.max(16)
					.regex(
						/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
						'password'
					)
					.required(),
				// Password should atleast be a minimum 0f 8 characters and
				// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
				// confirmPassword: Joi.string()
				// 	.min(8)
				// 	.max(16)
				// 	.regex(
				// 		/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
				// 		'password'
				// 	)
				// 	.required(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			const { email, mobile, password, role_id } = ctx.request.body;
			try {
				// //match password and confirm password
				// if (password !== confirmPassword) {
				// 	return Response.conflict(ctx, {
				// 		code: 41,
				// 		msg: 'Password and Confirm Password does not match!',
				// 	});
				// }
				// Added a validation if the user send an empty/null email value
				// They shouldn't go to checkUser and search user with null in email
				if (email == '') {
					return Response.conflict(ctx, {
						code: 41,
						msg: 'Email empty please remove the field or put email in the column!',
					});
				}

				// Check if user exists
				const checkUser = await prismaClient.users.findFirst({
					where: {
						OR: [
							{
								mobile: mobile,
							},
							{
								email: email,
							},
						],
					},
				});

				//console.log(checkUser, '111111111111111111111');
				if (checkUser) {
					if (checkUser.mobile == mobile) {
						return Response.success(ctx, {
							code: 41,
							msg: `Mobile is already registered !`,
							error: `Mobile is already registered !`,
						});
					} else if (checkUser.email == email) {
						return Response.success(ctx, {
							code: 41,
							msg: ` Email is already registered ! `,
							error: ` Email is already registered !`,
						});
					}
				}
				// Hash the password
				const hash = Bcrypt.hashSync(password, 10);
				// Create a new user
				const userReturn = await prismaClient.users.create({
					data: {
						email: email,
						name: inputs.value.name,
						mobile: mobile,
						password: hash,
						is_active: true,
						role_id: role_id,
						app_id: 3,
					},
					select: {
						id: true,
						email: true,
						name: true,
						mobile: true,
						app_id: true,
						roles: {
							select: {
								id: true,
								name: true,
							},
						},
					},
				});
				const user = await ParseBigInt(userReturn);

				// Return
				return Response.created(ctx, {
					code: 20,
					msg: 'Signup Successful!',
					data: {
						id: user.id,
						name: user.name,
						email: user.email,
						mobile: user.mobile,
						UserRole: user.roles.name,
					},
				});
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};
	//User Signin
	static async signin(ctx) {
		try {
			// Input validation
			const schema = Joi.object({
				email: Joi.string().min(6).max(50).required(),
				password: Joi.string().min(7).max(16).required(),
			});
			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			const { email, password } = ctx.request.body;
			// Check if user exists locally
			const userReturn = await prismaClient.users.findFirst({
				where: {
					email,
					is_active: true,
				},
				select: {
					id: true,
					email: true,
					name: true,
					password: true,
					passwordexpirydate: true,
					mobile: true,
					apps: {
						select: {
							id: true,
							name: true,
						},
					},
					roles: {
						select: {
							id: true,
							name: true,
						},
					},
				},
			});

			const checkUser = await ParseBigInt(userReturn);

			try {
				// If exists
				if (!checkUser) {
					// Return
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'User not found login!',
					});
				}
				// Compare password
				const passwordCheck = await Bcrypt.compareSync(
					password,
					checkUser.password
				);
				// Return
				if (!passwordCheck) {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'Password does not match!',
					});
				}

				//Password Expiry Check
				if (checkUser) {
					const userPassReturn = await prismaClient.users.findFirst({
						where: {
							email,
							passwordexpirydate: {
								gte: new Date().toISOString(),
							},
						},
						select: {
							email: true,
							passwordexpirydate: true,
						},
					});

					const checkUserPasswordExpiry = await ParseBigInt(userPassReturn);
					if (!checkUserPasswordExpiry) {
						return Response.badRequest(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'Password expired!',
						});
					}
				}
				//------------------------------------------------------------------------------------------------------------
				// JWT generate - accessToken
				const accessToken = Jwt.sign(
					{
						id: checkUser['id'],
						role_id: checkUser.roles.id,
						name: checkUser.name,
						mobile: checkUser.mobile,
						email: checkUser['email'],
						app_id: checkUser.apps.id,
						isActive: checkUser['is_active'],
					},
					jwtSignature.accessSecret,
					{
						expiresIn: '7d',
					}
				);
				return Response.success(ctx, {
					statusCode: 200,
					code: 20,
					msg: 'Successful login!',
					data: {
						id: checkUser.id,
						roles: checkUser['roles'],
						name: checkUser['name'],
						email: checkUser['email'],
						token: accessToken,
					},
				});
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error In check user',
				error: err,
			});
		}
	}
	// Generating Otp for a User and saving it in DB
	static generateOtp = async (ctx) => {
		try {
			// Get Input
			const schema = Joi.object({
				email: Joi.string().email(),
			});
			// Validate
			const inputs = await schema.validate(ctx.request.body);
			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			const { email } = ctx.request.body;
			try {
				// Email OTP generation
				if (email) {
					// Check if user exists
					const checkUnverifiedUser = await prismaClient.users.findFirst({
						where: {
							email,
						},
					});
					// If user does not exist
					if (!checkUnverifiedUser) {
						// Return
						return Response.badRequest(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'User not found!',
						});
					}
					// Check if there is an existing OTP that hasn't expired yet
					const existingOtp = await prismaClient.otp.findFirst({
						where: {
							for: email,
							is_expired: false,
							created_at: {
								gt: new Date(Date.now() - 2 * 60 * 1000), // OTP should not have been created more than 5 minutes ago
							},
						},
					});

					let otp;
					// If there is an existing OTP, use the same one
					if (existingOtp) {
						otp = existingOtp.otp;
					} else {
						// Otherwise, generate a new OTP
						otp = Math.floor(Math.random() * (9999 - 999 + 1) + 999).toString();
						// Create OTP
						await prismaClient.otp.create({
							data: {
								otp: otp,
								for: email,
								otp_type_id: 1,
								is_expired: false,
							},
						});
					}
					// // Generate OTP
					// const otp = Math.floor(
					// 	Math.random() * (9999 - 999 + 1) + 999
					// ).toString();
					// // Create OTP
					// await prismaClient.otp.create({
					// 	data: {
					// 		otp: otp,
					// 		for: email,
					// 		otp_type_id: 1,
					// 		is_expired: false,
					// 	},
					// });

					//send email
					const mailBody = ` Hi ${checkUnverifiedUser.name} \n Your verification otp Is: ${otp}. \n This OTP will expire in 2 minutes.`;
					const subject = 'OTP';

					// Return
					return Response.success(ctx, {
						statusCode: 200,
						code: 20,
						msg: 'OTP sent to your email!!',
						data: sendEmail(email, subject, mailBody),
						// data: {
						// 	Otp: otp,
						// 	data: sendEmail(email, subject, mailBody),
						// 	for: inputs.value.email,
						// 	otp_type_id: 1,
						// 	is_expired: false,
						// },
					});
				} else {
					// Return
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'OTP could not be sent!',
					});
				}
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};
	// Verify OTP
	static confirmOtp = async (ctx) => {
		try {
			const schema = Joi.object({
				email: Joi.string().email(),
				otp: Joi.string().min(4).max(4).required(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}

			const { email, otp } = ctx.request.body;

			if (email) {
				// Check if user exists
				const checkUser = await prismaClient.users.findFirst({
					where: {
						email,
					},
				});
				// Check if user exists
				if (!checkUser) {
					// Return
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'User not found!',
					});
				}

				// Check if OTP exists
				const checkOtp = await prismaClient.otp.findFirst({
					where: {
						for: email,
						otp,
						is_expired: false,
					},
					orderBy: {
						created_at: 'desc',
					},
				});

				// If OTP not found
				if (!checkOtp) {
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'Invalid OTP!',
					});
				}
				// set the validity of the otp to 5 mins
				const endTime = Moment(checkOtp.created_at, 'h:mma').add(2, 'm');
				var beginningTime = Moment(new Date(), 'h:mma');
				//var endTime = moment('9:00am', 'h:mma');
				const checkOTPTime = beginningTime.isAfter(endTime);
				if (checkOTPTime == true) {
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'OTP expired!',
					});
				}
				// Update OTP state
				await prismaClient.otp.update({
					where: {
						id: +checkOtp.id,
					},
					data: {
						is_expired: true,
					},
				});
				const datas = await prismaClient.users.findFirst({
					where: {
						email,
					},
				});
				return Response.success(ctx, {
					statusCode: 200,
					code: 20,
					data: {
						id: datas.id,
						name: datas.name,
						email: datas.email,
						mobile: datas.mobile,
					},
					msg: 'OTP Verified!',
				});
			}
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	//--------------------------------------
	// All Users
	static getAllUsers = async (ctx) => {
		try {
			const limit = ctx.request.query.limit || 10;
			const offset = ctx.request.query.offset || 0;
			const search = ctx.request.query.search;
			var output;
			if (search != 0 && search != undefined) {
				output = await prismaClient.users.findMany({
					orderBy: {
						updated_at: 'desc',
					},
					where: {
						OR: [
							{
								name: {
									contains: search,
									mode: 'insensitive',
								},
							},

							{
								email: {
									contains: search,
									mode: 'insensitive',
								},
							},
						],
					},
					skip: parseInt(offset),
					take: parseInt(limit),
					select: {
						id: true,
						name: true,
						email: true,
						mobile: true,
						is_active: true,
						created_at: true,
						updated_at: true,
						apps: {
							select: {
								id: true,
								name: true,
							},
						},
						roles: {
							select: {
								id: true,
								name: true,
							},
						},
					},
				});
				const searchCount = await prismaClient.alerts.count({
					where: {
						OR: [
							{
								name: {
									contains: search,
									mode: 'insensitive',
								},
							},

							{
								email: {
									contains: search,
									mode: 'insensitive',
								},
							},
						],
					},
				});
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Users successful',
					count: searchCount,
					data: output,
					code: 20,
				});
			} else {
				const UsersList = await prismaClient.users.findMany({
					skip: parseInt(offset),
					take: parseInt(limit),
					orderBy: {
						updated_at: 'desc',
					},
					select: {
						id: true,
						name: true,
						email: true,
						mobile: true,
						is_active: true,
						created_at: true,
						updated_at: true,
						apps: {
							select: {
								id: true,
								name: true,
							},
						},
						roles: {
							select: {
								id: true,
								name: true,
							},
						},
					},
				});
				const count = await prismaClient.users.count({});

				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Users successful',
					count,
					data: UsersList,
					code: 20,
				});
			}
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting users',
				error: err,
			});
		}
	};

	//Delete User By Id
	static async deleteUser(ctx) {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}

		try {
			const deletedUser = await prismaClient.users.delete({
				where: {
					id: parseInt(ctx.request.query.id),
				},
			});

			return Response.success(ctx, {
				statusCode: 200,
				msg: 'User Deleted Successfully',
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error deleting user',
				error: err,
			});
		}
	}
	//Update Password By Id
	static updatePassword = async (ctx) => {
		const schema = Joi.object({
			id: Joi.number().required(),
			// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
			password: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				)
				.required(),
		});

		const validation = schema.validate(ctx.request.body);
		if (validation.error) {
			console.log(validation.error);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data!',
				error: validation.error.details,
			});
		}
		const { id, password } = ctx.request.body;

		const profile = await prismaClient.users.findUnique({
			where: {
				id,
			},
			select: {
				id: true,
				name: true,
				role_id: true,
			},
		});

		if (profile.role_id == 3) {
			return Response.unauthorized(ctx, {
				code: 41,
				msg: "You don't have access to change the admin user password.",
				// error:"You don't have access to change the admin user password.",
			});
		}

		const hash = Bcrypt.hashSync(password, 10);
		try {
			const isUpdate = !!(await prismaClient.users.update({
				where: {
					id,
				},
				data: {
					password: hash,
					updated_at: new Date().toISOString(),
				},
			}));

			if (!isUpdate) {
				return Response.notFound(ctx, {
					code: 24,
					msg: 'Password  Update Failed!',
				});
			}
			return Response.success(ctx, {
				statusCode: 201,
				code: 21,
				msg: 'Password updated successfully',
				data: isUpdate,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	//Forgot Password By Id
	static forgotPassword = async (ctx) => {
		const schema = Joi.object({
			id: Joi.number().required(),
			// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
			password: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				)
				.required(),
		});

		const validation = schema.validate(ctx.request.body);
		if (validation.error) {
			console.log(validation.error);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data!',
				error: validation.error.details,
			});
		}
		const { id, password } = ctx.request.body;

		const hash = Bcrypt.hashSync(password, 10);
		try {
			const isUpdate = !!(await prismaClient.users.update({
				where: {
					id,
				},
				data: {
					password: hash,
					updated_at: new Date().toISOString(),
				},
			}));

			if (!isUpdate) {
				return Response.notFound(ctx, {
					code: 24,
					msg: 'Password  Update Failed!',
				});
			}
			return Response.success(ctx, {
				statusCode: 201,
				code: 21,
				msg: 'Password updated successfully',
				data: isUpdate,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	////Update User By Id
	static async updateUser(ctx) {
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}
		try {
			// Input validation
			const schema = Joi.object({
				name: Joi.string().min(1).max(40),
				mobile: Joi.string().min(6).max(12),
				is_active: Joi.boolean(),
				role_id: Joi.number(),
			});
			// Validate
			const inputs = schema.validate(ctx.request.body);
			if (inputs.error) {
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}

			// Check if user exists locally
			try {
				var output = await prismaClient.users.findUnique({
					where: {
						id: parseInt(ctx.request.query.id),
					},
					select: {
						id: true,
					},
				});

				const userReturns = await prismaClient.users.findFirst({
					where: {
						mobile: inputs.value.mobile,
					},
				});

				if (userReturns) {
					if (userReturns.mobile == inputs.value.mobile) {
						return Response.success(ctx, {
							code: 41,
							msg: 'User are already registered with same phone number !',
						});
					}
				}
				//-----------------------------------------------------------------------------
				if (!output) {
					return Response.success(ctx, {
						statusCode: 500,
						msg: 'user not found',
					});
				}

				var userReturn = await prismaClient.users.update({
					where: {
						id: parseInt(ctx.request.query.id),
					},
					data: inputs.value,
				});
				return Response.success(ctx, {
					statusCode: 200,
					code: 20,
					msg: 'user updated',
					data: userReturn,
				});
			} catch (err) {
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error could not update user',
					error: err,
				});
			}
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error In check user',
				error: err,
			});
		}
	}

	// API to get the profile of a user
	static getProfile = async (ctx) => {
		const id = parseInt(ctx.request.query.id);
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 400,
				code: 40,
				msg: 'Id not passed pls select id',
			});
		}
		try {
			const profileReturn = await prismaClient.users.findUnique({
				where: {
					id,
				},
				select: {
					id: true,
					name: true,
					roles: {
						select: {
							id: true,
							name: true,
						},
					},
					created_at: true,
					mobile: true,
					email: true,
				},
			});
			const profile = await ParseBigInt(profileReturn);

			if (!profile) {
				return Response.notFound(ctx, {
					code: 24,
					msg: 'Profile Not Found!',
				});
			}
			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Data Found!',
				data: profile,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	// API to update a user's profile Password
	static updateProfilePassword = async (ctx) => {
		const id = parseInt(ctx.request.query.id);
		if (!ctx.request.query.id) {
			return Response.badRequest(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Id not passed pls select id',
			});
		}
		//Get Input
		const schema = Joi.object({
			oldPassword: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				),
			newPassword: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				),
		});

		//Validate
		const inputs = await schema.validate(ctx.request.body);

		if (inputs.error) {
			console.log(inputs.error);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data!',
				error: inputs.error.details,
			});
		}
		const { oldPassword, newPassword } = ctx.request.body;

		const data = {};

		// Change Password
		if (oldPassword && newPassword) {
			const user = await prismaClient.users.findUnique({
				where: {
					id,
				},
			});

			if (!Bcrypt.compareSync(oldPassword, user.password)) {
				return Response.unauthorized(ctx, {
					msg: 'Password does not match!',
				});
			}

			if (oldPassword === newPassword) {
				return Response.unauthorized(ctx, {
					msg: 'Password can not same as Previous Password!',
				});
			}

			const new_hash = Bcrypt.hashSync(newPassword, 10);
			data.password = new_hash;
		}

		data.updated_at = new Date().toISOString();
		try {
			const update = await prismaClient.users.update({
				where: {
					id: id,
				},
				data,
			});
			if (!update) {
				return Response.notFound(ctx, {
					code: 24,
					msg: 'Profile Not Found!',
				});
			}

			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Password Updated!',
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	//
	static forgotPasswords = async (ctx) => {
		try {
			const schema = Joi.object({
				mobile: Joi.string().min(6).max(12).required(),
				// Password should atleast be a minimum 0f 8 characters and
				// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
				password: Joi.string()
					.min(8)
					.max(16)
					.regex(
						/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
						'password'
					)
					.required(),
				otp: Joi.string().min(4).max(4).required(),
				country_code: Joi.string(),
			});

			const validation = schema.validate(ctx.request.body);

			if (validation.error) {
				console.log(validation.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: validation.error.details,
				});
			}
			const { mobile, password, otp } = ctx.request.body;

			// Check if user exists
			const userReturn = await prismaClient.customers.findFirst({
				where: {
					mobile,
				},
			});
			const checkUser = await ParseBigInt(userReturn);

			// Check if user exists
			if (!checkUser) {
				// Return
				return Response.success(ctx, {
					statusCode: 400,
					code: 40,
					msg: 'User not found!',
				});
			}
			// Check if OTP exists
			const checkOtp = await prismaClient.customer_otp.findFirst({
				where: {
					for: mobile,
					otp,
					is_expired: false,
				},
				orderBy: {
					created_at: 'asc',
				},
			});

			// If OTP not found
			if (!checkOtp) {
				return Response.success(ctx, {
					statusCode: 400,
					code: 40,
					msg: 'Invalid OTP!',
				});
			}
			// Update OTP state
			await prismaClient.customer_otp.update({
				where: {
					id: +checkOtp.id,
				},
				data: {
					is_expired: true,
				},
			});

			const hash = Bcrypt.hashSync(password, 10);

			const updateUserReturn = await prismaClient.customers.update({
				where: {
					id: +checkUser.id,
				},
				data: {
					password_hash: hash,
				},
			});
			const updateUser = await ParseBigInt(updateUserReturn);

			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Records Found!',
				data: updateUser,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	static test = async (ctx) => {
		try {
			const { mobile } = ctx.request.body;

			const test = await prismaClient.customer_otp.findMany({
				where: {
					for: mobile,
					is_expired: true,
				},
			});

			if (test.length < 1) {
				return Response.success(ctx, {
					statusCode: 400,
					code: 42,
					msg: 'Mobile not verified!',
					data: [],
				});
			}

			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Mobile is verified!',
				data: test,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	// API to update a user's profile
	static updateProfile = async (ctx) => {
		const id = +ctx.state.user.id;
		//Get Input
		const schema = Joi.object({
			first_name: Joi.string().alphanum().max(40),
			last_name: Joi.string().alphanum().max(40),
			email: Joi.string().email(),
			mobile: Joi.string().min(6).max(12),
			title_id: Joi.number(),
			old_password: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				),
			new_password: Joi.string()
				.min(8)
				.max(16)
				.regex(
					/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
					'password'
				),
			dob: Joi.any(),
		});

		//Validate
		const inputs = await schema.validate(ctx.request.body);

		if (inputs.error) {
			console.log(inputs.error);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data!',
				error: inputs.error.details,
			});
		}
		const {
			first_name,
			last_name,
			email,
			title_id,
			old_password,
			new_password,
			dob,
		} = ctx.request.body;
		const data = {};
		if (first_name) data.first_name = first_name;
		if (last_name) data.last_name = last_name;
		if (email) data.email = email;
		if (title_id) data.title_id = title_id;
		if (dob) data.dob = new Date(dob);

		// Change Password
		if (old_password && new_password) {
			const user = await prismaClient.customers.findUnique({
				where: {
					id,
				},
			});

			if (!Bcrypt.compareSync(old_password, user.password_hash)) {
				return Response.unauthorized(ctx, {
					msg: 'Password does not match!',
				});
			}
			const new_hash = Bcrypt.hashSync(new_password, 10);
			data.password_hash = new_hash;
		}

		// Img Upload

		try {
			const update = await prismaClient.customers.update({
				where: {
					id: id,
				},
				data,
			});
			if (!update) {
				return Response.notFound(ctx, {
					code: 24,
					msg: 'Profile Not Found!',
				});
			}

			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Profile Updated!',
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};

	// Get the possible titles of the user
	static titles = async (ctx) => {
		try {
			const titles = await prismaClient.titles.findMany();
			return Response.success(ctx, {
				statusCode: 201,
				code: 21,
				msg: 'List of titles',
				data: titles,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};
	// Guest User Signup
	static addGuestUser = async (ctx) => {
		try {
			//Get Input
			const schema = Joi.object({
				// First name and last name should not contain any special characters
				first_name: Joi.string().alphanum().max(40).required(),
				last_name: Joi.string().alphanum().max(40),
				email: Joi.string().email(),
				mobile: Joi.string().min(6).max(12),
				android_id: Joi.string().min(8).max(20).required(),
				country_code: Joi.string(),
				title_id: Joi.number(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			try {
				const {
					title_id,
					country_code,
					android_id,
					mobile,
					email,
					last_name,
					first_name,
				} = ctx.request.body;
				// Added a validation if the user send an empty/null email value
				// They shouldn't go to checkUser and search user with null in email
				if (inputs.value.email == '') {
					return Response.conflict(ctx, {
						code: 41,
						msg: 'Email empty please remove the field or put email in the column!',
					});
				}
				console.log(inputs.value);
				let country_code_id = null;
				if (inputs.value.country_code) {
					country_code_id = await GetCountryCode(country_code);
				}

				// Create a new user
				const userReturn = await prismaClient.guest_users.create({
					data: {
						email,
						first_name,
						last_name,
						title_id,
						mobile,
						country_code_id: country_code_id ? +country_code_id.id : null,
						android_id,
						is_active: true,
					},
				});
				const user = await ParseBigInt(userReturn);

				// Return
				return Response.created(ctx, {
					code: 20,
					msg: 'Signup Successful!',
					data: {
						id: user.id,
						first_name: user.first_name,
						last_name: user.last_name,
						email: user.email,
						mobile: user.mobile,
						title_id: user.title_id,
						android_id: user.android_id,
					},
				});
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};

	// Test API to fetch OTP of a mobile number
	static getOtp = async (ctx) => {
		try {
			// Get Input
			const schema = Joi.object({
				mobile: Joi.string().min(6).max(12).required(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			const { mobile } = ctx.request.body;
			// Check OTP
			const user = await prismaClient.customer_otp.findMany({
				where: {
					for: mobile,
					is_expired: false,
				},
				orderBy: {
					created_at: 'desc',
				},
				take: 1,
			});

			if (user.length < 1) {
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'No OTP found!',
					data: [],
				});
			}

			// Return
			return Response.created(ctx, {
				code: 20,
				msg: 'OTP found!',
				data: user,
			});
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};

	//  API to fetch Country code of a mobile number
	static getCountryCode = async (ctx) => {
		try {
			// Fetch all country code along with their flags
			const country_code_raw = await prismaClient.country_code.findMany();

			// If no Data found
			if (country_code_raw.length < 1) {
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'No Data found!',
					data: [],
				});
			}

			// Parse BigInt to String
			const country_code = await ParseBigInt(country_code_raw);

			// Return
			return Response.created(ctx, {
				code: 20,
				msg: 'Data found!',
				data: country_code,
			});
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Internal Error!',
			});
		}
	};

	// Signin
	static async signinWeb(ctx) {
		try {
			// Input validation
			const schema = Joi.object({
				mobile: Joi.string().min(6).max(12).required(),
				password: Joi.string().min(8).max(16).required(),
				country_code_id: Joi.number().required(),
			});
			// Validate
			const inputs = await schema.validate(ctx.request.body);
			const { mobile, password, country_code_id } = ctx.request.body;

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}

			// check if the user have verified their phone number
			const verifiedUser = await prismaClient.customers.findFirst({
				where: {
					mobile,
					country_code_id,
					is_active: false,
					is_mobile_verified: false,
				},
			});

			if (verifiedUser) {
				return Response.success(ctx, {
					statusCode: 406,
					code: 42,
					msg: 'Mobile not verified!',
					data: [],
				});
			}
			// Check if user exists locally
			const userReturn = await prismaClient.customers.findFirst({
				where: {
					mobile,
					is_active: true,
					country_code_id,
				},
			});
			const checkUser = await ParseBigInt(userReturn);
			try {
				// If exists
				if (!checkUser) {
					// Return
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'User not found login!',
					});
				}
				// Compare password
				const passwordCheck = await Bcrypt.compareSync(
					password,
					checkUser['password_hash']
				);
				// Return
				if (!passwordCheck) {
					return Response.unauthorized(ctx, {
						statusCode: 401,
						code: 41,
						msg: 'Password does not match!',
					});
				}
				// JWT generate - accessToken
				const accessToken = Jwt.sign(
					{
						id: checkUser['id'],
						mobile: checkUser['mobile'],
						isActive: checkUser['is_active'],
					},
					jwtSignature.accessSecret,
					{
						expiresIn: '7d',
					}
				);
				// Return
				return Response.success(ctx, {
					statusCode: 200,
					code: 20,
					msg: 'Successful login!',
					data: {
						id: checkUser['id'],
						first_name: checkUser['first_name'],
						last_name: checkUser['last_name'],
						mobile: checkUser['mobile'],
						token: accessToken,
					},
				});
			} catch (err) {
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error In check user',
				error: err,
			});
		}
	}
	// User Signup
	static signupWeb = async (ctx) => {
		try {
			// Get Input
			const schema = Joi.object({
				// First name and last name should not contain any special characters
				first_name: Joi.string().alphanum().min(1).max(40).required(),
				last_name: Joi.string().alphanum().min(1).max(40).required(),
				email: Joi.string().email(),
				mobile: Joi.string().min(6).max(12).required(),
				country_code_id: Joi.number().required(),
				title_id: Joi.number(),
				// Password should atleast be a minimum 0f 8 characters and
				// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
				password: Joi.string()
					.min(8)
					.max(16)
					.regex(
						/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
						'password'
					)
					.required(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			try {
				// Added a validation if the user send an empty/null email value
				// They shouldn't go to checkUser and search user with null in email
				if (inputs.value.email == '') {
					return Response.conflict(ctx, {
						code: 41,
						msg: 'Email empty please remove the field or put email in the column!',
					});
				}

				// check if the user have verified their phone number
				const verifiedUser = await prismaClient.customers.findFirst({
					where: {
						mobile: inputs.value.mobile,
						country_code_id: inputs.value.country_code_id,
						is_active: false,
						is_mobile_verified: false,
					},
				});

				if (verifiedUser) {
					return Response.success(ctx, {
						statusCode: 400,
						code: 42,
						msg: 'Mobile not verified!',
						data: [],
					});
				}
				// Check if user exists
				const checkUser = await prismaClient.customers.findFirst({
					where: {
						OR: [
							{
								mobile: inputs.value.mobile,
								country_code_id: inputs.value.country_code_id,
							},
							{
								email: inputs.value.email,
							},
						],
					},
				});

				if (checkUser) {
					return Response.conflict(ctx, {
						statusCode: 409,
						code: 41,
						msg: 'You are already registered!',
					});
				}

				// Hash the password
				const hash = Bcrypt.hashSync(inputs.value.password, 10);
				// Create a new user
				const userReturn = await prismaClient.customers.create({
					data: {
						email: inputs.value.email,
						first_name: inputs.value.first_name,
						last_name: inputs.value.last_name,
						title_id: inputs.value.title_id,
						mobile: inputs.value.mobile,
						country_code_id: inputs.value.country_code_id,
						password_hash: hash,
						is_active: false,
						is_mobile_verified: false,
						is_email_verified: false,
					},
				});
				const user = await ParseBigInt(userReturn);

				// Return
				return Response.created(ctx, {
					code: 20,
					msg: 'Signup Successful!',
					data: {
						id: user.id,
						first_name: user.first_name,
						last_name: user.last_name,
						email: user.email,
						mobile: user.mobile,
						title_id: user.title_id,
					},
				});
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};

	// Generating Otp for a customer and saving it in DB
	static generateOtpWeb = async (ctx) => {
		try {
			// Get Input
			const schema = Joi.object({
				email: Joi.string().email(),
				mobile: Joi.string().min(6).max(12),
				country_code_id: Joi.number().required(),
			});
			// Validate
			const inputs = await schema.validate(ctx.request.body);
			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}
			try {
				// Mobile OTP generation
				if (inputs.value.mobile) {
					// Generate OTP
					const otp = Math.floor(
						Math.random() * (9999 - 999 + 1) + 999
					).toString();
					const welcomeMessage = `Your verification code is ${otp}`;

					// Function to send message to the user's phone number
					sendSms(inputs.value.mobile, welcomeMessage);

					// Create OTP
					await prismaClient.customer_otp.create({
						data: {
							otp: otp,
							for: inputs.value.mobile,
							country_code_id: inputs.value.country_code_id,
							otp_type_id: 1,
							is_expired: false,
						},
					});
					// Return
					return Response.success(ctx, {
						statusCode: 200,
						code: 20,
						msg: 'OTP Sent to your mobile number!',
					});
				}
				// Email OTP generation
				else if (inputs.value.email) {
					// Check if user exists
					const checkUnverifiedUser = await prismaClient.customers.findFirst({
						where: {
							email: inputs.value.email,
						},
					});
					// If user does not exist
					if (!checkUnverifiedUser) {
						// Return
						return Response.success(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'User not found!',
						});
					}
					// If user email is verified
					if (checkUnverifiedUser.is_email_verified === true) {
						// Return
						return Response.success(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'Email already verified!',
						});
					}
					// Generate OTP
					const otp = Math.floor(
						Math.random() * (9999 - 999 + 1) + 999
					).toString();
					// Create OTP
					await prismaClient.customer_otp.create({
						data: {
							otp: otp,
							for: inputs.value.email,
							otp_type_id: 1,
							is_expired: false,
						},
					});
					// Return
					return Response.success(ctx, {
						statusCode: 200,
						code: 20,
						msg: 'OTP sent to your email!!',
					});
				} else {
					// Return
					return Response.badRequest(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'OTP could not be sent!',
					});
				}
			} catch (err) {
				console.log(err);
				return Response.error(ctx, {
					statusCode: 500,
					code: 50,
					msg: 'Internal Error',
					error: err,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.badRequest(ctx, {
				code: 40,
				msg: 'Please provide valid data !',
			});
		}
	};

	// Verify OTP
	static confirmOtpWeb = async (ctx) => {
		try {
			const schema = Joi.object({
				email: Joi.string().email(),
				mobile: Joi.string().min(6).max(12),
				otp: Joi.string().min(4).max(4).required(),
				country_code_id: Joi.number().required(),
			});

			// Validate
			const inputs = await schema.validate(ctx.request.body);

			if (inputs.error) {
				console.log(inputs.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: inputs.error.details,
				});
			}

			const { mobile, email, otp, country_code_id } = ctx.request.body;

			if (mobile) {
				// Check if user exists
				const checkUser = await prismaClient.customers.findFirst({
					where: {
						mobile,
						country_code_id,
					},
				});
				// Check if user exists
				if (checkUser && checkUser.is_mobile_verified == true) {
					// Check if OTP exists
					const checkOtp = await prismaClient.customer_otp.findFirst({
						where: {
							for: mobile,
							country_code_id,
							otp,
							is_expired: false,
						},
						orderBy: {
							created_at: 'asc',
						},
					});

					// If OTP not found
					if (!checkOtp) {
						return Response.success(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'Invalid OTP!',
						});
					}
					// Return
					return Response.success(ctx, {
						statusCode: 200,
						code: 20,
						msg: 'OTP Verified!',
					});
				} else {
					// Check if OTP exists
					const checkOtp = await prismaClient.customer_otp.findFirst({
						where: {
							for: mobile,
							otp,
							country_code_id,
							is_expired: false,
						},
						orderBy: {
							created_at: 'asc',
						},
					});

					// If OTP not found
					if (!checkOtp) {
						return Response.success(ctx, {
							statusCode: 400,
							code: 40,
							msg: 'Invalid OTP!',
						});
					}
					// Update OTP state
					await prismaClient.customer_otp.update({
						where: {
							id: +checkOtp.id,
						},
						data: {
							is_expired: true,
						},
					});
					const data = await ParseBigInt(checkUser);
					// Update User state
					await prismaClient.customers.update({
						where: {
							id: +data.id,
						},
						data: {
							is_active: true,
							is_mobile_verified: true,
						},
					});

					// Return
					return Response.success(ctx, {
						statusCode: 200,
						code: 20,
						msg: 'OTP Verified!',
					});
				}
			} else if (email) {
				// Check if user exists
				const checkUser = await prismaClient.customers.findFirst({
					where: {
						email,
					},
				});
				// Check if user exists
				if (!checkUser) {
					// Return
					return Response.success(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'User not found!',
					});
				}
				// Check if OTP exists
				const checkOtp = await prismaClient.customer_otp.findFirst({
					where: {
						for: email,
						otp,
						is_expired: false,
					},
					orderBy: {
						created_at: 'desc',
					},
				});
				// If OTP not found
				if (!checkOtp) {
					return Response.success(ctx, {
						statusCode: 400,
						code: 40,
						msg: 'Invalid OTP!',
					});
				}
				// Update OTP state
				await prismaClient.customer_otp.update({
					where: {
						id: +checkOtp.id,
					},
					data: {
						is_expired: true,
					},
				});
				const data = await ParseBigInt(checkUser);

				// Update User state
				await prismaClient.customers.update({
					where: {
						id: +data.id,
					},
					data: {
						is_active: true,
						is_email_verified: true,
					},
				});
				// Return
				return Response.success(ctx, {
					statusCode: 200,
					code: 20,
					msg: 'OTP Verified!',
				});
			}
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};
	//
	static forgotPasswordWeb = async (ctx) => {
		try {
			const schema = Joi.object({
				mobile: Joi.string().min(6).max(12).required(),
				// Password should atleast be a minimum 0f 8 characters and
				// Should have atleast 1 uppercase, 1 lowercase, 1 number and 1 special character
				password: Joi.string()
					.min(8)
					.max(16)
					.regex(
						/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
						'password'
					)
					.required(),
				otp: Joi.string().min(4).max(4).required(),
				country_code_id: Joi.number().required(),
			});

			const validation = schema.validate(ctx.request.body);

			if (validation.error) {
				console.log(validation.error);
				return Response.badRequest(ctx, {
					code: 40,
					msg: 'Please provide valid data!',
					error: validation.error.details,
				});
			}
			const { mobile, password, otp, country_code_id } = ctx.request.body;

			// Check if user exists
			const userReturn = await prismaClient.customers.findFirst({
				where: {
					mobile,
					country_code_id,
				},
			});
			const checkUser = await ParseBigInt(userReturn);

			// Check if user exists
			if (!checkUser) {
				// Return
				return Response.success(ctx, {
					statusCode: 400,
					code: 40,
					msg: 'User not found!',
				});
			}
			// Check if OTP exists
			const checkOtp = await prismaClient.customer_otp.findFirst({
				where: {
					for: mobile,
					country_code_id,
					otp,
					is_expired: false,
				},
				orderBy: {
					created_at: 'asc',
				},
			});

			// If OTP not found
			if (!checkOtp) {
				return Response.success(ctx, {
					statusCode: 400,
					code: 40,
					msg: 'Invalid OTP!',
				});
			}
			// Update OTP state
			await prismaClient.customer_otp.update({
				where: {
					id: +checkOtp.id,
				},
				data: {
					is_expired: true,
				},
			});

			const hash = Bcrypt.hashSync(password, 10);

			const updateUserReturn = await prismaClient.customers.update({
				where: {
					id: +checkUser.id,
				},
				data: {
					password_hash: hash,
				},
			});
			const updateUser = await ParseBigInt(updateUserReturn);

			return Response.success(ctx, {
				statusCode: 200,
				code: 20,
				msg: 'Records Found!',
				data: updateUser,
			});
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Internal Error',
				error: err,
			});
		}
	};
};

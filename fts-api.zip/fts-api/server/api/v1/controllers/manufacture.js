/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
// Import Response Util
const Response = require('../utils/response');

module.exports = class manfacturecontroller {
    constructor() { }
    static async getAllManufacture(ctx) {
        try {
            const vehicleslist = await prismaClient.vehicle_manufacturers.findMany();
            return Response.success(ctx, {
                code: 200,
                msg: 'get data successful',
                data: vehicleslist
            });
        } catch (err) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting drivers',
                error: err
            });
        }
    }
};
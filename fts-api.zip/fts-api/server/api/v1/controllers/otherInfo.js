/* eslint-disable indent */
'use strict';
// Import Bcrypt

const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

module.exports = class routerAssignmentcontroller {
    constructor() { }
    static async getOtherInfo(ctx) {
        const currentTime = new Date();
        const startTime = currentTime.toLocaleString();
        console.log(startTime);
        try {
            // const schema = Joi.object({
            //     vehicle_id: Joi.integer().number(),
            // });
            // const inputs = schema.validate(ctx.request.body);
            // if (inputs.error) {
            //     console.log(inputs.error);
            //     return Response.badRequest(ctx, {
            //         code: 400,
            //         msg: 'Please provide valid data !!',
            //         error: inputs.error.details
            //     });
            // }
            const uid = await prismaClient.vehicle_assignments.findFirst({
                where: {
                    vehicle_id: parseInt(ctx.params.vehicle_id)
                },
                select: {
                    devices: {
                        select: {
                            uid: true
                        }
                    }
                }
            });
            console.log(uid);
            const fuelAndSpeed = await prismaClient.device_data.aggregate({
                _avg:{
                    fuel : true,
                    spd : true,
                },
                where: {
                    // time: {
                    //     gte: currentTime.toISOString(),
                    //     lte: currentTime.toISOString()
                    // }, 
                    uid : uid.devices.uid
                },
                // select : {
                //     lat:true,lng:true,time:true
                // },120
            });
            // console.log(fuelAndSpeed);
            const list = await prismaClient.device_data.findMany({
                
                where:{
                        uid : uid.devices.uid,
                    //     time: {
                    //     gte: currentTime.toISOString(),
                    //     lte: currentTime.toISOString()
                    // }
                },
                select:{
                    lat:true,lng:true,time:true
                }
            });
            console.log(list[0],list[list.length -1]);
            const first = list[0];
            const last = list[list.length -1] ;
            const firstDate = new Date(first.time);
            const lastDate = new Date(last.time);
            const distanceQuery = await prismaClient.$queryRaw ` SELECT ST_DistanceSphere(ST_MakePoint(${first.lng}, ${first.lat}),ST_MakePoint(${last.lng}, ${last.lat})) `;
            const distance = distanceQuery[0].st_distancesphere / 1000 ;
            console.log(distance);
            const time  = lastDate.getHours() - firstDate.getHours() ;
            const speed = distance / time ; 

            const outputObject = { 
                speed : speed,
                fuel : fuelAndSpeed._avg.fuel,
                distance : distance
            };
            return Response.success(ctx, {
                statusCode: 200,
                msg: 'successful',
                data: outputObject,
            });
        } catch (err) {
            console.log(err);
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting routes',
                error: err
            });
        }
    }
};
/* eslint-disable indent */
'use strict';
// Import JWT
const Jwt = require('jsonwebtoken');
// Import Bcrypt
const Bcrypt = require('bcrypt');
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
const { AlertsScalarFieldEnum } = require('@prisma/client');
// Import Settings
const { jwtSignature } = require('../../../config/adaptor');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');

// Alert Controller
module.exports = class ReportController {
	constructor() {}

	// All Report - Types
	static getAllReportTypes = async (ctx) => {
		try {
			const limit = ctx.request.query.limit || 10;
			const offset = ctx.request.query.offset || 0;
			const ReportsList = await prismaClient.report_types.findMany({
				skip: parseInt(offset),
				take: parseInt(limit),
			});
			const count = await prismaClient.report_types.count({});
			return Response.success(ctx, {
				statusCode: 200,
				msg: 'get Reports successful',
				count,
				data: ReportsList,
				code: 20,
			});
		} catch (err) {
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting reports',
				error: err,
			});
		}
	};

	// All Reports
	static getAllReports = async (ctx) => {
		const { typeId } = ctx.request.query;
		if (!typeId) {
			return Response.badRequest(ctx, {
				statusCode: 400,
				code: 40,
				msg: 'Report-Type is not selected. Please select Report-Type.',
			});
		}

		try {
			if (typeId == 1) {
				console.log('lllllllllllllllllll');
				const startTime = new Date(ctx.request.query.start_time).toISOString();
				const endTime = new Date(ctx.request.query.end_time).toISOString();
				// const vehicleId = ctx.request.query.vehicle_id;
				// console.log(startTime, endTime, vehicleId);
				// eslint-disable-next-line indent
				// if (!vehicleId) {
				//     console.log('pass vehicle id');
				//     return Response.badRequest(ctx, {
				//         statusCode: 500,
				//         code: 50,
				//         msg: 'vehicle id not selected',
				//     });
				// }

				// const output =  await prismaClient.$queryRaw` SELECT fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4) `;
				// console.log(` select fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4)`);

				const output =
					await prismaClient.$queryRawUnsafe`select "date",location::json as site_location,cast(speed as int4),vehicle_no,last_signal_received,cast(distance as int4) from fts_status_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone);`;
				console.log(
					`select "date",location::json as site_location,speed,vehicle_no,last_signal_received,distance from fts_status_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone where vehicle_id =  ;`
				);

				console.log(output);
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get status Reports successful',
					data: output,
					code: 20,
					count: output.length,
				});

				// const statusList = [{
				//     sl_no: 1,
				//     vehicle_no: '7753AQ',
				//     speed: 60,
				//     location: 'Bengaluru, Karnataka 560102',
				//     distance: 54,
				//     last_signal_received: '2023-03-30 16:02:05'
				// }, {
				//     sl_no: 2,
				//     vehicle_no: '7753AW',
				//     speed: 60,
				//     location: 'Patna, Bihar 800006',
				//     distance: 54,
				//     last_signal_received: '2023-03-30 19:02:05'
				// }];
				// const counts = statusList.length;

				// const data = {
				//     status_list: statusList,
				//     count: counts
				// }
				// return Response.success(ctx, {
				//     statusCode: 200,
				//     msg: 'get Status Reports successful',
				//     data: data,
				//     code: 20,
				// });
			}
			if (ctx.request.query.typeId == 2) {
				const startTime = new Date(ctx.request.query.start_time).toISOString();
				const endTime = new Date(ctx.request.query.end_time).toISOString();
				const vehicleId = ctx.request.query.vehicle_id;
				console.log(startTime, endTime, vehicleId);
				// eslint-disable-next-line indent
				if (!vehicleId) {
					console.log('pass vehicle id');
					return Response.badRequest(ctx, {
						statusCode: 500,
						code: 50,
						msg: 'vehicle id not selected',
					});
				}

				// const output =  await prismaClient.$queryRaw` SELECT fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4) `;
				// console.log(` select fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4)`);

				const output =
					await prismaClient.$queryRawUnsafe`select time_spend as "time" ,end_time,start_time,position::json as site_location from fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`;
				console.log(
					`select sl_no,position::json as site_location from fts_halts_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`
				);
				console.log(output);
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get Halt Reports successful',
					data: output,
					code: 20,
					count: output.length,
				});
			}
			if (ctx.request.query.typeId == 3) {
				const startTime = new Date(ctx.request.query.start_time).toISOString();
				const endTime = new Date(ctx.request.query.end_time).toISOString();
				const vehicleId = ctx.request.query.vehicle_id;
				console.log(startTime, endTime, vehicleId);
				if (!vehicleId) {
					console.log('pass vehicle id');
					return Response.badRequest(ctx, {
						statusCode: 500,
						code: 50,
						msg: 'vehicle id not selected',
					});
				}

				const output =
					await prismaClient.$queryRawUnsafe` select vehicle_name , "date" , cast(avg as int4) , cast(max as int4) , halt_count , halt_time , cast(distance as int4) from fts_general_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`;
				console.log(
					`select vehicle_name , "date" , cast(avg as int4)  , cast(max as int4)  , halt_count , halt_time , cast(distance as int4) from fts_general_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`
				);
				console.log(output);
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get general Reports successful',
					data: output,
					code: 20,
					count: output.length,
				});

				// select fts_general_report('2023-03-17 16:14:11.185 +0530','2023-04-11 17:13:43.555 +0530',24)

				// const generalList = [{
				//     sl_no: 1,
				//     vehicle_no: '7753AQ',
				//     distance_km: '500',
				//     average_speed_kmph: 50,
				//     maximum_speed_kmph: 70,
				//     halts: 4,
				//     halt_time_min: '15',
				// }, {
				//     sl_no: 2,
				//     vehicle_no: '7753XT',
				//     distance_km: '400',
				//     average_speed_kmph: 45,
				//     maximum_speed_kmph: 60,
				//     halts: 5,
				//     halt_time_min: '20',
				// }];
				// const counts = generalList.length;

				// const data = {
				//     status_list: generalList,
				//     count: counts
				// }
				// return Response.success(ctx, {
				//     statusCode: 200,
				//     msg: 'get General Reports successful',
				//     data: data,
				//     code: 20,
				// });
			}
			if (ctx.request.query.typeId == 4) {
				console.log(ctx.request.query, '22222222222222222');
				const startTime = new Date(ctx.request.query.start_time).toISOString();
				const endTime = new Date(ctx.request.query.end_time).toISOString();
				const vehicleId = ctx.request.query.vehicle_id;
				console.log(startTime, endTime, vehicleId);
				if (!vehicleId) {
					console.log('pass vehicle id');
					return Response.badRequest(ctx, {
						statusCode: 500,
						code: 50,
						msg: 'vehicle id not selected',
					});
				}

				const output =
					await prismaClient.$queryRawUnsafe` select "time", startTime, destinationTime , startLng , startLat , destinationLng,destinationLat,cast(distance as int4),cast(avgSpd as int4),cast(maxSpd as int4),engineOnTime from fts_trip_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`;
				console.log(
					`select vehicle_name , "date" , avg :: float4 , max  :: float4 , halt_count , halt_time , distance from fts_general_report(${startTime}::timestamp with time zone,${endTime}::timestamp with time zone,${vehicleId}::int4);`
				);
				console.log(output);
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'get trip Reports successful',
					data: output,
					code: 20,
					count: output.length,
				});

				//     const tripList = [{
				//         sl_no: 1,
				//         Position: 'Bengaluru, Karnataka 560102',
				//         starting_time: '2023-03-30 16:02:05',
				//         starting_point: 'Location',
				//         destination_time: '2023-03-30 17:02:05',
				//         destination_point: 'Location',
				//         distance: 400,
				//         avg_speed: 50,
				//         max_speed: 60,
				//         engine_on_time: 'N/A',
				//         action: 'N/A'
				//     }, {
				//         sl_no: 1,
				//         Position: 'Bengaluru, Karnataka 560102',
				//         starting_time: '2023-03-30 16:02:05',
				//         starting_point: 'Location A',
				//         destination_time: '2023-03-30 17:02:05',
				//         destination_point: 'Location B',
				//         distance: 400,
				//         avg_speed: 50,
				//         max_speed: 60,
				//         engine_on_time: 'N/A',
				//         action: 'N/A'
				//     }];
				//     const counts = tripList.length;

				//     const data = {
				//         status_list: tripList,
				//         count: counts
				//     }
				//     return Response.success(ctx, {
				//         statusCode: 200,
				//         msg: 'get Trip Reports successful',
				//         data: data,
				//         code: 20,
				//     });
			}
			if (ctx.request.query.typeId == 5) {
				console.log(ctx.request.query, '22222222222222222');
				const startTime = new Date(ctx.request.query.start_time).toISOString();
				const endTime = new Date(ctx.request.query.end_time).toISOString();
				const vehicleId = ctx.request.query.vehicle_id;
				console.log(startTime, endTime, vehicleId);
				if (!vehicleId) {
					console.log('pass vehicle id');
					return Response.badRequest(ctx, {
						statusCode: 500,
						code: 50,
						msg: 'vehicle id not selected',
					});
				}

				const output = await prismaClient.$queryRawUnsafe` 	select
                time_bucket_gapfill('1 days',
                a.created_at) as ts,
                cast(coalesce (count(a.alert_type_id), 0) as integer) as Counts,
                a.geo_name  as geo_name,
                a.resolved as resolve
            from
                alerts a
                join alert_types at2  on (at2.id=a.alert_type_id)
            where
                a.created_at >= ${startTime} ::timestamp with time zone
                and a.created_at <= ${endTime}::timestamp with time zone
                and vehicle_id = ${parseInt(vehicleId)}
                and a.alert_type_id = 1
            group by
                ts,
                a.alert_type_id,
                a.geo_name,
                a.resolved
            order by
                ts desc ,
                alert_type_id ;`;

				console.log(output);
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'Get Fence Reports successful',
					data: output,
					code: 20,
					count: output.length,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.error(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting alerts',
				error: err,
			});
		}
	};

	//Status Reports

	static async getStatusReports(ctx) {
		const { vehicle_id, typeId, start_time, end_time } = ctx.request.query;
		if (!typeId) {
			return Response.badRequest(ctx, {
				statusCode: 400,
				code: 40,
				msg: 'Report-Type is not selected. Please select Report-Type.',
			});
		}
		if (!vehicle_id) {
			return Response.badRequest(ctx, {
				statusCode: 400,
				code: 40,
				msg: 'Vehicle is not selected. Please select Vehicle.',
			});
		}
		const currentTime = new Date();
		const startTime = currentTime.toLocaleString();
		console.log(typeId, '1111111111111111');
		try {
			if (typeId == 3) {
				const uid = await prismaClient.vehicle_assignments.findFirst({
					where: {
						vehicle_id: parseInt(vehicle_id),
					},
					select: {
						id: true,
						devices: {
							select: {
								uid: true,
							},
						},
						vehicles: {
							select: {
								id: true,
								vehicle_no: true,
							},
						},
					},
				});
				console.log(uid, '1111111111111');
				const fuelAndSpeed = await prismaClient.device_data.aggregate({
					_avg: {
						fuel: true,
						spd: true,
					},
					where: {
						// time: {
						//     gte: currentTime.toISOString(),
						//     lte: currentTime.toISOString()
						// },
						uid: uid.devices.uid,
					},
					// select : {
					//     lat:true,lng:true,time:true
					// },120
				});
				console.log(fuelAndSpeed, '22222222222');
				const list = await prismaClient.device_data.findMany({
					where: {
						uid: uid.devices.uid,
						//     time: {
						//     gte: currentTime.toISOString(),
						//     lte: currentTime.toISOString()
						// }
					},
					select: {
						lat: true,
						lng: true,
						time: true,
					},
				});
				console.log(list[0], list[list.length - 1]);
				const first = list[0];
				const last = list[list.length - 1];
				const firstDate = new Date(first.time);
				const lastDate = new Date(last.time);
				const distanceQuery =
					await prismaClient.$queryRaw` SELECT ST_DistanceSphere(ST_MakePoint(${first.lng}, ${first.lat}),ST_MakePoint(${last.lng}, ${last.lat})) `;
				const distance = distanceQuery[0].st_distancesphere / 1000;
				console.log(distance);
				const time = lastDate.getHours() - firstDate.getHours();
				const speed = distance / time;

				const outputObject = {
					speed: speed,
					fuel: fuelAndSpeed._avg.fuel,
					distance: distance,
				};
				return Response.success(ctx, {
					statusCode: 200,
					msg: 'successful',
					data: outputObject,
				});
			}
		} catch (err) {
			console.log(err);
			return Response.success(ctx, {
				statusCode: 500,
				code: 50,
				msg: 'Error getting routes',
				error: err,
			});
		}
	}

	// 	try {
	// 		const limit = ctx.request.query.limit || 10;
	// 		const offset = ctx.request.query.offset || 0;
	// 		const startTime = ctx.request.query
	// 		const endTime = ctx.request.query
	// 			//geofence List
	// 			const geofenceAlertsList = await prismaClient.alerts.groupBy({
	// 				by: [  AlertsScalarFieldEnum.created_at],
	// 				skip: parseInt(offset),
	// 				take: parseInt(limit),
	// 				where: {
	// 					created_at: {
	// 						gt : new Date(startTime.startTime).toISOString(),
	// 						lt: new Date(endTime.endTime).toISOString(),
	// 					},
	// 					AND : {
	// 						alert_type_id : 1
	// 					}
	// 				},
	// 				select: {
	// 					created_at: true,
	// 					id: true,
	// 					alert_type_id : true
	// 					// alert_types: {
	// 					// 	select: {
	// 					// 		id: true,
	// 					// 		name: true,
	// 					// 	},
	// 					// },
	// 				},
	// 			});

	// 			//Temper List
	// 			const temperAlertsList = await prismaClient.alerts.groupBy({
	// 				by: [  AlertsScalarFieldEnum.created_at],
	// 				skip: parseInt(offset),
	// 				take: parseInt(limit),
	// 				where: {
	// 					created_at: {
	// 						gt : new Date(startTime.startTime).toISOString(),
	// 						lt: new Date(endTime.endTime).toISOString(),
	// 					},
	// 					AND : {
	// 						alert_type_id : 2
	// 					}
	// 				},
	// 				select: {
	// 					created_at: true,
	// 					id: true,
	// 					alert_type_id : true
	// 					// alert_types: {
	// 					// 	select: {
	// 					// 		id: true,
	// 					// 		name: true,
	// 					// 	},
	// 					// },
	// 				},
	// 			});

	// 			//group the geofence alerts by date and alert ID
	// 			const geofenceAlertsCount = groupAlertsByDateAndAlertId(geofenceAlertsList);

	// 			//group the temperature alerts by date and alert ID
	// 			const temperAlertsCount = groupAlertsByDateAndAlertId(temperAlertsList);

	// 			function groupAlertsByDateAndAlertId(alerts) {
	// 				const result = {};
	// 				alerts.forEach((alert) => {
	// 				  const date = alert.created_at.toDateString();
	// 				  const alertId = alert.alert_type_id;
	// 				  if (!result[date]) {
	// 					result[date] = {};
	// 				  }
	// 				  if (!result[date][alertId]) {
	// 					result[date][alertId] = 0;
	// 				  }
	// 				  result[date][alertId] += alert._count.id;
	// 				});
	// 				return result;
	// 			  }

	// 			//results
	// 			let result = {
	// 				geofenceList : {
	// 					outOfGeofence: geofenceAlertsList,
	// 					count : (geofenceAlertsList.length)
	// 				},
	// 				temperList : {
	// 					temper: temperAlertsList,
	// 					count : (temperAlertsList.length)
	// 				}
	// 			}

	// 			return Response.success(ctx, {
	// 				statusCode: 200,
	// 				msg: 'get Alerts successful',
	// 				data: result,
	// 				code: 20,
	// 			});

	// 	} catch (err) {
	// 		console.log(err);
	// 		return Response.error(ctx, {
	// 			statusCode: 500,
	// 			code: 50,
	// 			msg: 'Error getting alerts',
	// 			error: err,
	// 		});
	// 	}
	// };
};

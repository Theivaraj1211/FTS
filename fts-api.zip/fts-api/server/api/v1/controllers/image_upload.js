/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
// Import JOI
// Import Response Util
const Response = require('../utils/response');
var Minio = require('minio');
var settings = require('../../../config/settings.dev');
var Joi = require('joi');
var MinioClient = new Minio.Client({
    endPoint: settings.minio.url,
    port: settings.minio.port,
    useSSL: false,
    accessKey: settings.minio.accessKey,
    secretKey: settings.minio.secretKey,
});

module.exports = class imageUploadcontroller {
    constructor() { }
    static async ImageUpload(ctx) {
        let minioPromise = [];
        try {
            // Input validation
            const schema = Joi.object({
                images: Joi.array().max(5).min(0),
                name: Joi.string().required()
            });
            // Validate
            const inputs = schema.validate(ctx.request.body);
            if (inputs.error) {
                return Response.badRequest(ctx, {
                    code: 40,
                    msg: 'Please provide valid data!',
                    error: inputs.error.details,
                });
            }
            var images = [];
            if (inputs.value.images.length) {
                inputs.value.images.forEach((value, index) => {
                    console.log(index);
                    const imageBase64buffer = Buffer.from(value, 'base64');
                    const extension = 'png';
                    const timestamp = new Date().valueOf();
                    const fileName = inputs.value.name + '_' + index + '_' + timestamp + '.' + extension;
                    const img_url = settings.minio.imageBaseUrl + fileName;
                    images.push({
                        img_no: index,
                        url: img_url,
                        file_name: fileName,
                    });
                    // Storing Image in Minio Bucket
                    // Upload Image to minio
                    minioPromise.push(
                        MinioClient.putObject(
                            settings.minio.bucket_name,
                            fileName,
                            imageBase64buffer
                        )
                    );
                });
                return Response.success(ctx, {
                    statusCode: 201,
                    code: 20,
                    msg: 'image uploaded !',
                    data: images,
                    count: images.length
                });
            }
        } catch (err) {
            console.log(err);
            return Response.error(ctx, {
                statusCode: 500,
                code: 51,
                msg: 'Internal Error',
                error: err,
            });
        }
    }
};
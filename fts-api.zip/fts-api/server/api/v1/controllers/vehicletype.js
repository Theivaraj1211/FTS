'use strict';
// Import Bcrypt
const Bcrypt = require('bcrypt');
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
const Joi = require('joi');
// Import Response Util
const Response = require('../utils/response');
// Parse BigInt
const ParseBigInt = require('../utils/parse.bigint');
// Get Country code Id of a country
const GetCountryCode = require('../utils/getcountry.code');
// Twilio package for sending message
const sendSms = require('../utils/send.sms');
const prisma = require('../utils/prisma.client');
module.exports = class vehicletypecontroller {
    constructor() { }
    static async getAllVehicleType(ctx) {
        try {
            const vehicleslist = await prismaClient.vehicle_types.findMany().catch((e) => {
                console.log(e)
            })
            return Response.success(ctx, {
                code: 200,
                msg: 'get data successful',
                data: vehicleslist
            });

        } catch (err) {
            return Response.success(ctx, {
                statusCode: 500,
                code: 50,
                msg: 'Error getting drivers',
                error: err
            });
        }
    }
}
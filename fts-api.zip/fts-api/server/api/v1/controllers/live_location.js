/* eslint-disable indent */
'use strict';
// Import Bcrypt
// Import Prisma Client
const prismaClient = require('../utils/prisma.client');
// Import JOI
// Import Response Util
const Response = require('../utils/response');

//lat lng to address
const reverseGeo = require('../utils/getLocationFromLatLng');


module.exports = class live_location {
    constructor() { }
    static async getLiveLocation(ctx) {
        // console.log("---------------------");
        try {
            const device_vehicle_data = await prismaClient.vehicle_assignments.findFirst({
                where: {
                    vehicle_id: parseInt(ctx.params.vehicle_id),
                },
                select: {
                    devices: {
                        select: {
                            uid: true,
                            id: true,
                            is_moving: true,
                            tempar_status: true,
                            battery_level: true,
                            last_data_at: true,
                            lat: true,
                            lng: true
                        }
                    },
                    vehicles: {
                        select: {
                            id: true,
                            name: true,
                            chassis_no: true,
                            engine_no: true,
                            vehicle_no : true 
                        }
                    },
                    drivers: {
                        select: {
                            city: true,
                            driver_name: true,
                            driver_address: true,
                            id: true,
                            images: true,
                            driver_phone_no: true,
                            emergency_mobile_no: true
                        }
                    }
                }
            });
            var coordinates;
            if (ctx.request.query.starttime && ctx.request.query.endtime) {
                coordinates = await prismaClient.device_data.findMany({
                    orderBy : {
                        time : 'asc'
                    },
                    where: {
                        time: {
                            gte: new Date(ctx.request.query.starttime),
                            lte: new Date(ctx.request.query.endtime)
                        },
                        uid: device_vehicle_data.devices.uid
                    },
                    select: {
                        lat: true,
                        lng: true,
                        time: true
                    }
                });
                console.log(coordinates.length);
            } else {
                coordinates = await prismaClient.device_data.findMany({
                    orderBy : {
                        time : 'asc'
                    },
                    where: {
                        uid: device_vehicle_data.devices.uid
                    },
                    select: {
                        lat: true,
                        lng: true,
                        time: true
                    }
                });
                console.log(coordinates.length);
            }
            const finalOutput = {
                'vehicle_id': device_vehicle_data.vehicles.id,
                'vehicle_no' : device_vehicle_data.vehicles.vehicle_no,
                'address' : await reverseGeo(device_vehicle_data.devices.lat, device_vehicle_data.devices.lng),
                'vehicle_name': device_vehicle_data.vehicles.name,
                'last_location': device_vehicle_data.devices.last_data_at,
                'is_moving': device_vehicle_data.devices.is_moving,
                'battery_level': device_vehicle_data.devices.battery_level,
                'tamper_status': device_vehicle_data.devices.tempar_status,
                'device_id': device_vehicle_data.devices.uid,
                'driver_name': device_vehicle_data.drivers.driver_name,
                'driver_image' : device_vehicle_data.drivers.images,
                'driver_phone': device_vehicle_data.drivers.driver_phone_no,
                'vechile_chasis_no': device_vehicle_data.vehicles.chassis_no,
                'vechile_engine_no': device_vehicle_data.vehicles.engine_no,
                'geoPoint': {
                    geojson: {
                        type: 'Point',
                        coordinates: coordinates
                    },
                }
            };
            return Response.success(ctx, {
                code: 20,
                msg: 'get data successful',
                data: finalOutput
            });
        } catch (err) {
            return Response.success(ctx, {
                code: 50,
                msg: 'Error getting data',
                error: err
            });
        }
    }
};



// Import Koa
const Koa = require('koa');
// Import Koa Body Parser
const BodyParser = require('koa-bodyparser');
// Import Koa Cors
const Cors = require('@koa/cors');
// Import Router
const Router = require('./api/v1/routes');
// Import Swagger
const { koaSwagger } = require('koa2-swagger-ui');
// Import Config
const { swaggerBaseUrl } = require('./config/adaptor');
//Import Koa Morgan - Logger
const Morgan = require('koa-morgan');

// Koa
class App extends Koa {
	constructor(...params) {
		super(...params);
		//   this._setServices();
		this._setMiddlewares();
		this._setRoutes();
	}

	_setMiddlewares() {
		// Body Parser
		this.use(
			BodyParser({
				enableTypes: ['json', 'form'],
				jsonLimit: '10mb',
			})
		);
		// CORS
		this.use(Cors());
		//Morgan - Request Logger
		this.use(Morgan('combined'));
		// SWAGGER
		this.use(
			koaSwagger({
				routePrefix: '/api/v1/swagger-doc',
				swaggerOptions: {
					url: swaggerBaseUrl,
				},
			})
		);
	}

	_setRoutes() {
		// Application router
		this.use(Router.routes());
		this.use(Router.allowedMethods());
	}

	// Server listen
	listen(...args) {
		const server = super.listen(...args);
		return server;
	}
}

// Export App
module.exports = App;
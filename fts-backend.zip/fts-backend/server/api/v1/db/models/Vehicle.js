"use strict";
//Import Schema
const Schema = require("./Schema");
module.exports = (sequelize, DataTypes) => {
  const vehicleSchema = Schema(DataTypes).Schema.Vehicle;
  const Vehicle = sequelize.define("vehicle", vehicleSchema);

  Vehicle.associate = function (models) {
    // associations can be defined here
    Vehicle.hasMany(models.raw_data, {
      as: "data",
      foreignKey: {
        allowNull: false,
        name: "deviceId",
      },
      sourceKey: "deviceId",
    });
    Vehicle.hasOne(models.route, {
      foreignKey: {
        allowNull: false,
        name: "id",
      },
      sourceKey: "routeId",
    });
    Vehicle.hasOne(models.driver, {
      foreignKey: {
        allowNull: false,
        name: "deviceId",
      },
      sourceKey: "deviceId",
    });
  };
  return Vehicle;
};

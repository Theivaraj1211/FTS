"use strict";
//Import Schema
const Schema = require("./Schema");
module.exports = (sequelize, DataTypes) => {
  const alertSchema = Schema(DataTypes).Schema.Alert;
  const Alert = sequelize.define("alert", alertSchema, { timestamps: false });

  Alert.associate = function (models) {
    // associations can be defined here
  };
  return Alert;
};

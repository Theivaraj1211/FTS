"use strict";
//Import Koa Router
const Router = require("koa-router");
//Instantiate Router
const router = new Router();
//Import Controller
const Controller = require("./../controllers/data");
//Import Auth - Middleware
const Auth = require("./../middlewares/auth");

/*

! Data Routes

*/
//Get devices
router.get("/devices", Auth.jwtAuth, Controller.getAllDevices);

//Get devices
router.get("/vehicles", Auth.jwtAuth, Controller.getAllVehicles);

//Get single device routes
router.get(
  "/vehicles/:deviceId/routes",
  Auth.jwtAuth,
  Controller.getVehicleRoute
);
//Get Reports
router.get("/reports", Controller.getReports);

//Add Vehicle
router.post("/vehicle", Auth.jwtAuth, Controller.addVehicle);

//Update Vehicle
router.patch("/vehicle/:deviceId", Auth.jwtAuth, Controller.updateVehicle);

//Delete Vehicle
router.delete("/vehicle/:deviceId", Auth.jwtAuth, Controller.deleteVehicle);

//Get vehicle reminder
router.get("/vehicles/reminder", Auth.jwtAuth, Controller.getVehicleReminder);

//Get data counts
router.get("/vehicles/stats", Auth.jwtAuth, Controller.getVehicleStats);

//Get vehicle types
router.get("/vehicles/types", Auth.jwtAuth, Controller.getVehicleTypes);

//Get units
router.get("/units", Auth.jwtAuth, Controller.getUnits);

//Add Vehicle route
router.post("/routes", Auth.jwtAuth, Controller.AddRoute);

//Get routes
router.get("/routes", Auth.jwtAuth, Controller.getRoutes);

//Update route
router.patch("/routes/:routeId", Auth.jwtAuth, Controller.updateRoutes);

//Delete route
router.delete("/routes/:routeId", Auth.jwtAuth, Controller.deleteRoute);

//Get Alerts
router.get("/alerts", Auth.jwtAuth, Controller.getAlerts);

//Get Alerts count -  Auth.jwtAuth
router.get("/alerts/counts", Auth.jwtAuth, Controller.getAlertsCounts);

//Add Vehicle polygon
router.post("/polygons", Auth.jwtAuth, Controller.AddPolygon);

//Get polygons
router.get("/polygons", Auth.jwtAuth, Controller.getPolygons);

//Update polygon
router.patch("/polygons/:polygonId", Auth.jwtAuth, Controller.updatePolygon);

//Delete route
router.delete("/polygons/:polygonId", Auth.jwtAuth, Controller.deletePolygons);

//Update vehicle with one route
router.patch(
  "/vehicles/:deviceId/routes",
  Auth.jwtAuth,
  Controller.updateVehicleRoute
);

//Update vehicle with one polygon
router.patch(
  "/vehicles/:deviceId/polygons",
  Auth.jwtAuth,
  Controller.updateVehiclePolygon
);

//Get single device live data
router.get(
  "/vehicles/:deviceId/live-data",
  Auth.jwtAuth,
  Controller.getVehicleLiveData
);

//Bulk Vehicle Upload
router.post("/bulk-vehicle", Auth.jwtAuth, Controller.addBulkVehicle);

//Export
module.exports = router;
